"use strict";
(() => {
  // packages/schemas/index.ts
  var UMN_CAMPUSES = { UMNTC: { campus: "UMNTC", institution: "UMNTC", name: "Twin Cities" }, UMNDL: { campus: "UMNDL", institution: "UMNDL", name: "Duluth" }, UMNCR: { campus: "UMNCR", institution: "UMNCR", name: "Crookston" }, UMNMO: { campus: "UMNMO", institution: "UMNMO", name: "Morris" }, UMNRO: { campus: "UMNRO", institution: "UMNTC", name: "Rochester" } };
  function campusCode(value) {
    const s = value.trim().toUpperCase();
    if (!(s in UMN_CAMPUSES)) throw new Error("Invalid UMN campus");
    return s;
  }
  var APAS_CAMPUS_DIGITS = { "1": "UMNTC", "3": "UMNDL", "4": "UMNMO", "5": "UMNCR", "6": "UMNRO" };
  function parseCampusCourseCode(value) {
    const m = /^\s*([13456])?([A-Z]{2,8})\s*(\d{1,4}[A-Z]?)\s*$/i.exec(value);
    if (!m) throw new Error("Expected a UMN course code such as PSY 1001");
    const subject = m[2].toUpperCase(), catalogNumber = m[3].toUpperCase();
    return { code: `${subject} ${catalogNumber}`, campus: m[1] ? APAS_CAMPUS_DIGITS[m[1]] : void 0, subject, catalogNumber };
  }
  function courseCode(value) {
    return parseCampusCourseCode(value).code;
  }
  function instructorEntityKey(name, campus) {
    const clean = name.normalize("NFKD").replace(/[\u0300-\u036f]/g, "").toLowerCase().replace(/[^a-z0-9]+/g, " ").trim().replace(/\s+/g, " ");
    if (!clean || clean.length > 160) throw new Error("Invalid instructor name");
    return campus && campus !== "UMNTC" ? `instructor:${campus}:${clean}` : `instructor:${clean}`;
  }

  // packages/community/signals.ts
  function currentInstructorSignals(c) {
    if (c.course.data?.campus !== "UMNTC") return [];
    const current = [...new Map((c.sections.data || []).flatMap((s) => s.instructors).map((i) => [instructorEntityKey(i.name, "UMNTC"), i])).values()];
    return current.map((instructor) => {
      const key = instructorEntityKey(instructor.name, "UMNTC");
      const matches = (c.grades.data?.instructorRatings || []).filter((r) => instructorEntityKey(r.instructorName, "UMNTC") === key);
      const unique = new Map(matches.map((r) => [`${r.professorId}:${r.quality}`, r]));
      const rating = unique.size === 1 ? [...unique.values()][0] : void 0;
      const reference = c.community.find((r) => r.source === "ratemyprofessor" && r.entityType === "instructor" && r.entityId === key && /^https:\/\/www\.ratemyprofessors\.com\/professor\/\d+\/?$/.test(r.url));
      return { instructor, key, rating, originalUrl: reference?.url, searchUrl: `https://www.ratemyprofessors.com/search/professors/1257?q=${encodeURIComponent(instructor.name)}`, redditUrl: `https://www.reddit.com/r/uofmn/search/?q=${encodeURIComponent('"' + instructor.name + '"')}&restrict_sr=1&sort=new`, viaUrl: rating ? `https://umn.lol/inst/${rating.professorId}` : void 0 };
    });
  }
  function redditCourseSearch(code) {
    return `https://www.reddit.com/r/uofmn/search/?q=${encodeURIComponent('"' + code + '" OR "' + code.replace(/\s/g, "") + '"')}&restrict_sr=1&sort=new`;
  }
  function safeCommunityLink(value) {
    try {
      const u = new URL(value);
      return u.protocol === "https:" && !u.username && !u.password && ["www.reddit.com", "reddit.com", "www.ratemyprofessors.com", "umn.lol"].includes(u.hostname) ? u.href : void 0;
    } catch {
      return;
    }
  }

  // packages/ui/index.ts
  function escape(s) {
    return String(s ?? "").replace(/[&<>"']/g, (c) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" })[c]);
  }
  function date(s) {
    return new Date(s).toLocaleString(void 0, { month: "short", day: "numeric", hour: "numeric", minute: "2-digit" });
  }
  function termLabel(t) {
    return `${{ 3: "Spring", 5: "Summer", 9: "Fall" }[Number(t.at(-1))]} ${2e3 + Number(t.slice(1, 3))}`;
  }
  var GPA_POINTS = { "A+": 4.333, A: 4, "A-": 3.667, "B+": 3.333, B: 3, "B-": 2.667, "C+": 2.333, C: 2, "C-": 1.667, "D+": 1.333, D: 1, "D-": 0.667, F: 0 };
  function gradeDistributionSummary(grades) {
    const entries = Object.entries(grades).filter(([, n]) => Number.isFinite(n) && n > 0), students = entries.reduce((s, [, n]) => s + n, 0), impacting = entries.filter(([g]) => g in GPA_POINTS), impactingStudents = impacting.reduce((s, [, n]) => s + n, 0), gpa = impactingStudents ? impacting.reduce((s, [g, n]) => s + GPA_POINTS[g] * n, 0) / impactingStudents : void 0, averageLetter = gpa === void 0 ? void 0 : Object.entries(GPA_POINTS).reduce((best, [g, p]) => Math.abs(p - gpa) < Math.abs(GPA_POINTS[best] - gpa) ? g : best, "A"), most = entries.sort((a, b) => b[1] - a[1])[0];
    return { students, gpa: gpa === void 0 ? void 0 : Number(gpa.toFixed(2)), averageLetter, mostCommon: most?.[0], mostCommonPercent: students && most ? Math.round(100 * most[1] / students) : void 0 };
  }
  function gradeTermTrend(c) {
    const byTerm = /* @__PURE__ */ new Map();
    for (const row of c.grades.data?.distributions || []) {
      let bucket = byTerm.get(row.term);
      if (!bucket) {
        bucket = { students: 0, grades: {} };
        byTerm.set(row.term, bucket);
      }
      bucket.students += row.students;
      for (const [g, n] of Object.entries(row.grades)) bucket.grades[g] = (bucket.grades[g] || 0) + n;
    }
    return [...byTerm.entries()].sort(([a], [b]) => a.localeCompare(b)).map(([term, v]) => ({ term, students: v.students, gpa: gradeDistributionSummary(v.grades).gpa }));
  }
  function communityTopicSummary(c) {
    const counts = /* @__PURE__ */ new Map();
    for (const r of c.community) for (const topic of r.topics) counts.set(topic, (counts.get(topic) || 0) + 1);
    return [...counts.entries()].map(([topic, count]) => ({ topic, count })).sort((a, b) => b.count - a.count || a.topic.localeCompare(b.topic));
  }
  function currentInstructorGradeHistory(c) {
    const current = [...new Map((c.sections.data || []).flatMap((s) => s.instructors).map((i) => [i.id, i])).values()];
    const out = [];
    for (const i of current) {
      let key = "";
      try {
        key = instructorEntityKey(i.name);
      } catch {
        continue;
      }
      const rows = c.grades.data?.distributions.filter((d) => d.instructorName && instructorEntityKey(d.instructorName) === key) || [];
      if (!rows.length) continue;
      const grades = {};
      for (const row of rows) for (const [g, n] of Object.entries(row.grades)) grades[g] = (grades[g] || 0) + n;
      out.push({ name: i.name, students: rows.reduce((n, r) => n + r.students, 0), terms: [...new Set(rows.map((r) => r.term))].sort(), grades });
    }
    return out.sort((a, b) => b.students - a.students);
  }
  function referenceEntityLabel(c, entityType, entityId) {
    if (entityType === "course") return "Course";
    const campus = c.course.data?.campus;
    for (const i of [...new Map((c.sections.data || []).flatMap((s) => s.instructors).map((i2) => [i2.id, i2])).values()]) {
      try {
        if (instructorEntityKey(i.name, campus) === entityId || campus === "UMNTC" && instructorEntityKey(i.name) === entityId) return i.name;
      } catch {
      }
    }
    return "Instructor";
  }
  function communityHTML(c) {
    const code = c.course.data?.code || "", signals = currentInstructorSignals(c);
    return `<section class="community-evidence"><div class="community-heading"><div><small class="eyebrow">STUDENT PERSPECTIVES</small><h3>Beyond the grade.</h3></div><span class="evidence-label">Opinions, with context</span></div><p class="muted">Grades describe outcomes. Reviews describe experiences. Neither guarantees how a class will work for you.</p><div class="instructor-signals">${signals.map((s) => `<article class="instructor-signal"><div><h4>${escape(s.instructor.name)}</h4><small>Listed for ${termLabel(c.course.data.term)} \xB7 Twin Cities</small></div><div class="rmp-metric">${s.rating ? `<strong>${s.rating.quality.toFixed(1)}<small> / 5</small></strong><span>RMP overall quality</span>` : '<span class="muted">No matched rating available</span>'}</div>${s.rating ? `<p class="metric-provenance">Via <a href="${escape(s.viaUrl)}" target="_blank" rel="noopener noreferrer">GopherGrades \u2197</a> \xB7 ${c.grades.stale ? "Cached copy \xB7 " : ""}retrieved ${date(c.grades.provenance.retrievedAt)}<br>Rating count and rating update date not supplied. This is professor-wide, not a rating of this course.</p>` : ""}<div class="community-links"><a href="${escape(s.originalUrl || s.searchUrl)}" target="_blank" rel="noopener noreferrer">${s.originalUrl ? "Read RMP profile" : "Find on RMP"} \u2197</a><a href="${escape(s.redditUrl)}" target="_blank" rel="noopener noreferrer">Search professor discussions \u2197</a></div></article>`).join("") || '<p class="muted">Current instructor is not available yet. No professor rating has been guessed.</p>'}</div><div class="discussion-heading"><h4>What students discuss</h4><a href="${escape(redditCourseSearch(code))}" target="_blank" rel="noopener noreferrer">Search r/uofmn for ${escape(code)} \u2197</a></div><p class="muted">Look for workload, teaching style and assessments. Search links are discovery tools, not collected reviews.</p>${c.community.filter((r) => r.source !== "ratemyprofessor" && safeCommunityLink(r.url)).map((r) => `<article class="reference"><small>${escape(referenceEntityLabel(c, r.entityType, r.entityId))} \xB7 ${escape(r.source)} \xB7 ${escape(r.publishedAt?.slice(0, 10) || "Publication date unknown")}${r.publishedAt && Date.now() - Date.parse(r.publishedAt) > 730 * 864e5 ? " \xB7 Older than 2 years" : ""}</small><h4><a class="reference-title" href="${escape(safeCommunityLink(r.url))}" target="_blank" rel="noopener noreferrer">${escape(r.title)} \u2197</a></h4>${r.excerpt ? `<p>${escape(r.excerpt)}</p>` : '<p class="muted">Original link only; review text has not been collected.</p>'}<div class="topic-tags">${r.topics.map((t) => `<span>${escape(t)}</span>`).join("")}</div><small>${r.provenance.source.includes("reviewed-summary") ? "Reviewed summary \xB7 " : ""}Added ${date(r.discoveredAt)} \xB7 Individual experiences, not a representative survey</small></article>`).join("") || '<p class="muted">No collected Reddit discussion yet. Use the course or professor search above.</p>'}</section>`;
  }

  // packages/core/planning.ts
  var seasons = { "3": "Spring", "5": "Summer", "9": "Fall" };
  function termSeason(term) {
    const s = seasons[term.at(-1) || ""];
    if (!s) throw new Error("Unsupported UMN term");
    return s;
  }
  function offeringPattern(ctx) {
    const course = ctx.course.data, code = course?.code || "Unknown course";
    const observed = /* @__PURE__ */ new Set();
    for (const d of ctx.grades.data?.distributions || []) if (/^1\d{2}[359]$/.test(d.term)) observed.add(d.term);
    if (course?.term) observed.add(course.term);
    const observedTerms = [...observed].sort();
    const seasonCounts = { Spring: 0, Summer: 0, Fall: 0 };
    for (const t of observedTerms) seasonCounts[termSeason(t)]++;
    const seasonList = Object.entries(seasonCounts).filter(([, n]) => n > 0).sort((a, b) => b[1] - a[1]).map(([s]) => s);
    const confidence = observedTerms.length >= 6 ? "strong" : observedTerms.length >= 2 ? "limited" : "unknown";
    const label = !observedTerms.length ? "No historical offering signal" : seasonList.length === 3 ? "Observed across Fall, Spring and Summer" : seasonList.length ? `Observed most often in ${seasonList.join(" / ")}` : "Offering pattern unavailable";
    return { code, observedTerms, seasons: seasonList, confidence, label, seasonCounts };
  }

  // apps/extension/schedule-dom.ts
  var CACHE_MS = 3e4;
  var gradeOrder = ["A", "A-", "B+", "B", "B-", "C+", "C", "C-", "D+", "D", "D-", "F", "S", "N", "W"];
  var css = `
:host{--maroon:#7a0019;--line:#d5d6d2;--off:#f9f7f6;display:block;margin:10px 0 0;color:#2d2d2d;font:12px/1.35 -apple-system,BlinkMacSystemFont,"Segoe UI",Arial,sans-serif}
*{box-sizing:border-box}
.wrap{border-top:1px solid #dedede;padding-top:9px}
.topline{display:flex;align-items:center;gap:8px;margin-bottom:8px}
.brand{display:inline-flex;align-items:center;gap:6px;font-weight:750;color:#6d001f;letter-spacing:.01em}
.brand:before{content:"";width:5px;height:15px;border-radius:2px;background:#ffcc33;box-shadow:inset 0 0 0 1px #d7a900}
.context{margin-left:auto;color:#777;font-size:10px}
.rail{display:grid;grid-template-columns:repeat(auto-fit,minmax(160px,1fr));gap:8px}
.insight{position:relative;min-width:0;min-height:86px;padding:10px 11px;border:1px solid #dedede;border-radius:8px;background:#fff;text-align:left;color:#333;font:inherit;box-shadow:0 1px 2px rgba(0,0,0,.03)}
button.insight{cursor:pointer}
button.insight:hover,button.insight[aria-expanded="true"]{border-color:#6d001f;box-shadow:0 0 0 1px rgba(109,0,31,.08)}
.insight.good{border-left:4px solid #4d8a5b}
.insight.warn{border-left:4px solid #c6962c}
.insight.neutral{border-left:4px solid #6d001f}
.kicker{display:block;color:#767676;font-size:9px;font-weight:700;letter-spacing:.07em;text-transform:uppercase;margin-bottom:5px}
.value{display:block;color:#262626;font-size:13px;font-weight:720;line-height:1.2;white-space:nowrap;overflow:hidden;text-overflow:ellipsis}
.sub{display:block;color:#6f6f6f;font-size:10px;margin-top:4px;white-space:nowrap;overflow:hidden;text-overflow:ellipsis}
.spark{height:18px;display:flex;gap:2px;align-items:flex-end;margin-top:7px}
.spark i{display:block;flex:1;min-width:2px;border-radius:2px 2px 0 0;background:#d8d8d8;opacity:.9}
.spark i.a{background:#5e9b68}.spark i.b{background:#c2a638}.spark i.c{background:#c77c36}.spark i.d,.spark i.f{background:#b95c61}
.source-links{display:flex;gap:5px;flex-wrap:wrap;margin-top:7px}
.source-link{display:inline-flex;align-items:center;max-width:100%;padding:3px 6px;border:1px solid #e1d5d8;border-radius:999px;color:#6b2232;text-decoration:none;background:#fff7f8;font-size:9px;white-space:nowrap;overflow:hidden;text-overflow:ellipsis}
.source-link:hover{text-decoration:underline;border-color:#b98e98}
.more-link{color:#6b2232;text-decoration:none;font-size:10px}
.more-link:hover{text-decoration:underline}
.body{margin-top:9px;padding:12px 13px;background:#fafafa;border:1px solid #e4e4e4;border-radius:7px}
.body h4{font-size:12px;margin:0 0 8px;color:#444}
.body p{margin:6px 0 9px}
.muted{color:#777;font-size:10px}
.good-text{color:#28643a}.warn-text{color:#7d631e}.bad-text{color:#8c2f39}
.bars{display:grid;gap:5px;margin:8px 0 10px}
.bar{display:grid;grid-template-columns:28px 1fr 54px;gap:7px;align-items:center;font-size:10px}
.trend{margin:12px 0;padding:10px;border:1px solid #e3e3e3;border-radius:7px;background:#fff}.trend-head{display:flex;justify-content:space-between;gap:12px;align-items:baseline;margin-bottom:7px}.trend-head strong{font-size:11px}.trend-head span{font-size:9px;color:#777}.trend svg{display:block;width:100%;height:92px;overflow:visible}.trend-grid{stroke:#ececec;stroke-width:1}.trend-line{fill:none;stroke:#7a0019;stroke-width:2.5;stroke-linecap:round;stroke-linejoin:round}.trend-dot{fill:#ffcc33;stroke:#7a0019;stroke-width:1.5}.trend-labels{display:flex;justify-content:space-between;gap:6px;color:#777;font-size:8px;margin-top:5px}.topic-summary{display:grid;gap:6px;margin:9px 0 12px}.topic-row{display:grid;grid-template-columns:72px 1fr 26px;gap:7px;align-items:center;font-size:10px}.topic-row .track{height:6px}.topic-row .fill{background:#7a0019}.offering-grid{display:grid;grid-template-columns:repeat(3,1fr);gap:8px;margin:10px 0}.offering-cell{padding:9px;border:1px solid #e2e2e2;border-radius:6px;background:#fff}.offering-cell strong,.offering-cell span{display:block}.offering-cell strong{font-size:16px;color:#7a0019}.offering-cell span{font-size:9px;color:#777}.intel-note{margin-top:9px;padding:8px 9px;border-left:3px solid #ffcc33;background:#fff9df;font-size:10px;color:#5d532c}
.track{height:8px;border-radius:999px;background:#ececec;overflow:hidden}.fill{height:100%;background:#6d001f;border-radius:999px}
.reference{padding:9px 0;border-top:1px solid #e5e5e5}.reference:first-of-type{border-top:0}
.reference-title{display:block;color:#6b2232;font-weight:600;text-decoration:none;margin:2px 0 4px}.reference-title:hover{text-decoration:underline}
.tags{display:flex;gap:4px;flex-wrap:wrap;margin-top:5px}.tag{background:#eee;border-radius:3px;padding:1px 5px;color:#666;font-size:9px}
.actions{display:flex;gap:12px;align-items:center;margin-top:10px;padding-top:8px;border-top:1px solid #e6e6e6}
.actions a,.link-button{color:#6b2232;text-decoration:none;background:none;border:0;padding:0;font:inherit;cursor:pointer}.actions a:hover,.link-button:hover{text-decoration:underline}
.loading{color:#777}
.community-heading{display:flex;justify-content:space-between;gap:10px;align-items:center}.community-heading h3{margin:5px 0;font-size:18px}.eyebrow,.evidence-label{font-size:9px;letter-spacing:.04em;color:#6d001f}.instructor-signals{display:grid;gap:8px;margin:12px 0}.instructor-signal{display:grid;grid-template-columns:1fr auto;gap:8px;border:1px solid #dedede;background:#fff;padding:12px}.instructor-signal h4{margin:0 0 4px}.instructor-signal small{font-size:10px;color:#666}.rmp-metric{text-align:right}.rmp-metric strong{font-size:22px;color:#7a0019}.rmp-metric span{display:block;font-size:10px}.metric-provenance,.community-links{grid-column:1/-1;font-size:10px}.community-links{display:flex;gap:12px;flex-wrap:wrap}.community-evidence a{color:#7a0019}.discussion-heading{margin-top:16px}.topic-tags{display:flex;gap:5px;margin:6px 0}.topic-tags span{padding:2px 6px;background:#eee;font-size:10px}.reference h4{margin:6px 0}.reference>small{font-size:10px;color:#666}
@media(prefers-reduced-motion:no-preference){.body{animation:reveal .16s ease-out}@keyframes reveal{from{opacity:.4;transform:translateY(3px)}to{opacity:1;transform:translateY(0)}}}
@media(max-width:1050px){.rail{grid-template-columns:repeat(2,minmax(180px,1fr))}}
@media(max-width:680px){.rail{grid-template-columns:1fr}.context{display:none}.insight{min-height:74px}}
`;
  function detectTerm(doc) {
    const fromPath = (value) => {
      const match = /\/(\d{4})(Spring|Summer|Fall)\//.exec(value);
      return match ? `1${match[1].slice(2)}${{ Spring: 3, Summer: 5, Fall: 9 }[match[2]]}` : void 0;
    };
    const pathTerm = fromPath(doc.location?.pathname || "");
    if (pathTerm) return pathTerm;
    const term = doc.querySelector('select[name="term"]')?.value;
    if (term && /^1\d{2}[359]$/.test(term)) return term;
    const courseLink = doc.querySelector('#schedule-courses a.action-view[href*="/explore/"]');
    return courseLink ? fromPath(new URL(courseLink.href, doc.location?.href).pathname) : void 0;
  }
  function detectCampus(doc) {
    try {
      const fromPath = /\/redirect\/(UMN(?:TC|DL|CR|MO|RO))(?:\/|$)/.exec(doc.location?.pathname || "")?.[1];
      if (fromPath) return campusCode(fromPath);
      const raw = doc.defaultView?.localStorage.getItem("SB2_the_search_for_more_storage");
      if (!raw) return;
      const state = JSON.parse(raw);
      return state?.campus ? campusCode(String(state.campus)) : void 0;
    } catch {
      return;
    }
  }
  function findCards(doc) {
    const found = /* @__PURE__ */ new Map();
    for (const a of doc.querySelectorAll("a[name]")) {
      try {
        const code = courseCode(a.getAttribute("name") || "");
        const card = a.nextElementSibling;
        if (card?.matches(".panel")) found.set(card, code);
      } catch {
      }
    }
    for (const panel of doc.querySelectorAll(".course-list-results .panel")) {
      if (found.has(panel)) continue;
      const a = panel.parentElement?.querySelector("a[name]");
      try {
        if (a) found.set(panel, courseCode(a.getAttribute("name") || ""));
      } catch {
      }
    }
    for (const panel of doc.querySelectorAll(".panel")) {
      if (found.has(panel)) continue;
      const a = panel.querySelector('a.action-view[href*="/explore/"]');
      if (!a) continue;
      try {
        const href = new URL(a.href, doc.location?.href), m = /\/explore\/[^/]+\/([A-Z]{2,8})\/(\d{1,4}[A-Z]?)\/?/i.exec(href.pathname);
        if (m) found.set(panel, courseCode(m[1] + m[2]));
      } catch {
      }
    }
    for (const row of doc.querySelectorAll("#schedule-courses tr")) {
      const a = row.querySelector("h4 a.action-view[href]");
      if (!a) continue;
      const href = new URL(a.href, doc.location?.href);
      const m = /\/explore\/[^/]+\/([A-Z]{2,8})\/(\d{1,4}[A-Z]?)\/?/i.exec(href.pathname);
      try {
        found.set(row, courseCode(m ? m[1] + m[2] : (a.textContent || "").split(":")[0]));
      } catch {
      }
    }
    const info = doc.querySelector("#crse-info");
    if (info && !found.size) {
      const heading = info.querySelector(".panel-heading,h2,h3");
      const m = /\b([A-Z]{2,8})\s*(\d{1,4}[A-Z]?)\b/.exec(heading?.textContent || "");
      if (m) found.set(info, courseCode(m[1] + m[2]));
    }
    return [...found].map(([card, code]) => ({ card, code }));
  }
  function safeExternal(raw) {
    try {
      const u = new URL(raw);
      return u.protocol === "https:" || u.protocol === "http:" ? u.href : void 0;
    } catch {
      return;
    }
  }
  function plannerUrl(code, term, campus = "UMNTC") {
    return `http://127.0.0.1:4317/?course=${encodeURIComponent(code)}&term=${encodeURIComponent(term)}&campus=${encodeURIComponent(campus)}`;
  }
  function newestReferences(c) {
    return [...c?.community || []].sort((a, b) => (b.publishedAt || b.discoveredAt).localeCompare(a.publishedAt || a.discoveredAt));
  }
  function inlineMount(card, code) {
    if (card.tagName === "TR") {
      const existing = card.nextElementSibling;
      if (existing?.matches("tr.smart-umn-built-row")) return existing.querySelector("td") || existing;
      const row = card.ownerDocument.createElement("tr");
      row.className = "smart-umn-built-row";
      row.setAttribute("data-smart-umn-course", code);
      const cell = card.ownerDocument.createElement("td");
      cell.className = "smart-umn-built-cell";
      const span = [...card.children].reduce((n, c) => n + Math.max(1, c.colSpan || 1), 0);
      cell.colSpan = Math.max(1, span);
      cell.style.padding = "0 8px 10px";
      cell.style.background = "#fff";
      row.append(cell);
      card.insertAdjacentElement("afterend", row);
      return cell;
    }
    return card.querySelector(".panel-body") || card;
  }
  function removeInlineHost(host) {
    const row = host.closest("tr.smart-umn-built-row");
    if (row) row.remove();
    else host.remove();
  }
  function short(s, n) {
    return s.length > n ? s.slice(0, n - 1).trimEnd() + "\u2026" : s;
  }
  function el(doc, tag, className, text) {
    const node = doc.createElement(tag);
    if (className) node.className = className;
    if (text !== void 0) node.textContent = text;
    return node;
  }
  function gradeTone(grade) {
    return /^A/.test(grade) ? "a" : /^B/.test(grade) ? "b" : /^C/.test(grade) ? "c" : /^D/.test(grade) ? "d" : grade === "F" ? "f" : "";
  }
  function gradeSpark(doc, grades) {
    const order = ["F", "D-", "D", "D+", "C-", "C", "C+", "B-", "B", "B+", "A-", "A", "A+"], max = Math.max(1, ...order.map((g) => grades[g] || 0)), spark = el(doc, "div", "spark");
    spark.setAttribute("aria-label", "Historical grade distribution");
    for (const grade of order) {
      const count = grades[grade] || 0, i = el(doc, "i", gradeTone(grade));
      i.style.height = `${Math.max(count ? 14 : 2, Math.round(count / max * 100))}%`;
      i.title = `${grade}: ${count.toLocaleString()}`;
      spark.append(i);
    }
    return spark;
  }
  function insightButton(doc, kicker, value, sub, tone, tab, active, onToggle) {
    const b = el(doc, "button", `insight ${tone}`);
    b.type = "button";
    b.setAttribute("aria-expanded", String(active === tab));
    b.setAttribute("aria-label", `${kicker}: ${value}; ${active === tab ? "collapse" : "expand"} details`);
    b.append(el(doc, "span", "kicker", kicker), el(doc, "span", "value", value), el(doc, "span", "sub", sub));
    b.onclick = onToggle;
    return b;
  }
  function addPlannerAction(doc, parent, code, term, campus = "UMNTC") {
    const actions = el(doc, "div", "actions");
    const link = el(doc, "a");
    link.href = plannerUrl(code, term, campus);
    link.target = "_blank";
    link.rel = "noopener noreferrer";
    link.textContent = "Open full course page \u2197";
    actions.append(link);
    parent.append(actions);
  }
  function renderTrend(doc, parent, c) {
    const points = gradeTermTrend(c).filter((p) => p.gpa !== void 0).slice(-8);
    if (points.length < 2) return;
    const box = el(doc, "div", "trend"), head = el(doc, "div", "trend-head");
    head.append(el(doc, "strong", void 0, "Historical GPA trend"), el(doc, "span", void 0, `${points.length} reported terms \xB7 course-wide`));
    box.append(head);
    const svg = doc.createElementNS("http://www.w3.org/2000/svg", "svg");
    svg.setAttribute("viewBox", "0 0 320 92");
    svg.setAttribute("role", "img");
    svg.setAttribute("aria-label", "Historical course GPA trend by reported term");
    for (const y of [16, 46, 76]) {
      const line = doc.createElementNS("http://www.w3.org/2000/svg", "line");
      line.setAttribute("x1", "0");
      line.setAttribute("x2", "320");
      line.setAttribute("y1", String(y));
      line.setAttribute("y2", String(y));
      line.setAttribute("class", "trend-grid");
      svg.append(line);
    }
    const coords = points.map((p, i) => {
      const x = points.length === 1 ? 160 : i * (320 / (points.length - 1)), g = p.gpa ?? 0, y = 82 - Math.max(0, Math.min(4.33, g)) / 4.33 * 72;
      return { x, y, p };
    }), poly = doc.createElementNS("http://www.w3.org/2000/svg", "polyline");
    poly.setAttribute("points", coords.map((x) => `${x.x.toFixed(1)},${x.y.toFixed(1)}`).join(" "));
    poly.setAttribute("class", "trend-line");
    svg.append(poly);
    for (const x of coords) {
      const circle = doc.createElementNS("http://www.w3.org/2000/svg", "circle");
      circle.setAttribute("cx", x.x.toFixed(1));
      circle.setAttribute("cy", x.y.toFixed(1));
      circle.setAttribute("r", "4");
      circle.setAttribute("class", "trend-dot");
      const title = doc.createElementNS("http://www.w3.org/2000/svg", "title");
      title.textContent = `${termLabel(x.p.term)} \xB7 ${x.p.gpa?.toFixed(2)} GPA \xB7 ${x.p.students.toLocaleString()} students`;
      circle.append(title);
      svg.append(circle);
    }
    box.append(svg);
    const labels = el(doc, "div", "trend-labels");
    for (const p of points) labels.append(el(doc, "span", void 0, termLabel(p.term).replace("Spring", "Sp").replace("Summer", "Su").replace("Fall", "Fa")));
    box.append(labels);
    parent.append(box);
  }
  function renderOffering(doc, parent, c, code, term) {
    const pattern = offeringPattern(c);
    parent.append(el(doc, "h4", void 0, "Observed offering history"));
    parent.append(el(doc, "p", void 0, pattern.label));
    const grid = el(doc, "div", "offering-grid");
    for (const season of ["Fall", "Spring", "Summer"]) {
      const cell = el(doc, "div", "offering-cell");
      cell.append(el(doc, "strong", void 0, String(pattern.seasonCounts[season])), el(doc, "span", void 0, `${season} terms observed`));
      grid.append(cell);
    }
    parent.append(grid);
    if (pattern.observedTerms.length) {
      parent.append(el(doc, "p", "muted", `Observed terms: ${pattern.observedTerms.map(termLabel).join(" \xB7 ")}`));
    }
    parent.append(el(doc, "p", "intel-note", pattern.confidence === "strong" ? "Strong historical signal only \u2014 future offerings still require official confirmation." : "Limited historical signal \u2014 do not treat this as a promise that the course will be offered."));
    addPlannerAction(doc, parent, code, term, c.course.data?.campus || "UMNTC");
  }
  function renderGrades(doc, parent, c, code, term) {
    const g = c.grades.data;
    if (!g) {
      parent.append(el(doc, "p", "muted", c.grades.health.message || "Historical grades are unavailable right now."));
      addPlannerAction(doc, parent, code, term, c.course.data?.campus || "UMNTC");
      return;
    }
    parent.append(el(doc, "p", void 0, `Historical grade distribution \xB7 ${g.totalStudents.toLocaleString()} students`));
    const entries = Object.entries(g.grades).filter(([, n]) => n > 0).sort(([a], [b]) => {
      const ai = gradeOrder.indexOf(a), bi = gradeOrder.indexOf(b);
      return (ai < 0 ? 999 : ai) - (bi < 0 ? 999 : bi);
    });
    const max = Math.max(1, ...entries.map(([, n]) => n));
    const bars = el(doc, "div", "bars");
    for (const [grade, count] of entries) {
      const row = el(doc, "div", "bar");
      row.append(el(doc, "span", void 0, grade));
      const track = el(doc, "div", "track"), fill = el(doc, "div", "fill");
      fill.style.width = `${Math.max(1, count / max * 100)}%`;
      track.append(fill);
      row.append(track);
      row.append(el(doc, "span", void 0, count.toLocaleString()));
      bars.append(row);
    }
    parent.append(bars);
    renderTrend(doc, parent, c);
    const current = currentInstructorGradeHistory(c);
    if (current.length) {
      parent.append(el(doc, "h4", void 0, "Current instructor historical records"));
      for (const history of current) {
        parent.append(el(doc, "p", "muted", `${history.name} \xB7 ${history.students.toLocaleString()} historical students \xB7 ${history.terms.join(", ")}`));
        const rows = Object.entries(history.grades).filter(([, n]) => n > 0), max2 = Math.max(1, ...rows.map(([, n]) => n));
        const detail = el(doc, "div", "bars");
        for (const [grade, count] of rows) {
          const row = el(doc, "div", "bar");
          row.append(el(doc, "span", void 0, grade));
          const track = el(doc, "div", "track"), fill = el(doc, "div", "fill");
          fill.style.width = `${Math.max(1, count / max2 * 100)}%`;
          track.append(fill);
          row.append(track);
          row.append(el(doc, "span", void 0, count.toLocaleString()));
          detail.append(row);
        }
        parent.append(detail);
      }
    }
    parent.append(el(doc, "p", "muted", `GopherGrades \xB7 ${c.grades.provenance.period} \xB7 retrieved ${new Date(c.grades.provenance.retrievedAt).toLocaleString()}`));
    parent.append(el(doc, "p", "muted", "Historical outcomes describe past cohorts; they do not predict your grade."));
    addPlannerAction(doc, parent, code, term, c.course.data?.campus || "UMNTC");
  }
  function renderCommunity(doc, parent, c, code, term) {
    parent.innerHTML = communityHTML(c);
    const topics = communityTopicSummary(c);
    if (topics.length) {
      const summary = el(doc, "div", "topic-summary"), max = Math.max(...topics.map((t) => t.count), 1);
      for (const topic of topics.slice(0, 6)) {
        const row = el(doc, "div", "topic-row");
        row.append(el(doc, "span", void 0, topic.topic));
        const track = el(doc, "div", "track"), fill = el(doc, "div", "fill");
        fill.style.width = `${Math.max(8, topic.count / max * 100)}%`;
        track.append(fill);
        row.append(track, el(doc, "span", void 0, String(topic.count)));
        summary.append(row);
      }
      const section = parent.querySelector(".discussion-heading");
      section?.insertAdjacentElement("afterend", summary);
    }
    parent.append(el(doc, "p", "muted", "Community references are curated source material only. Reddit excerpts appear only when a reviewed/manual reference includes one; Smart UMN does not scrape Reddit or RateMyProfessors. RMP aggregates are third-party opinions, not a Smart UMN quality score."));
    const actions = el(doc, "div", "actions"), link = el(doc, "a", void 0, "Read sources & set my instructor preference \u2197");
    link.href = plannerUrl(code, term, c.course.data?.campus || "UMNTC");
    link.target = "_blank";
    link.rel = "noopener noreferrer";
    actions.append(link);
    parent.append(actions);
  }
  function renderDegree(doc, parent, fit, connected, code, term, campus, client) {
    if (!connected) {
      parent.append(el(doc, "p", void 0, "Connect UMN to show how this course fits your current APAS degree audit."));
      const button = el(doc, "button", "link-button", "Connect UMN \u2192");
      button.type = "button";
      button.onclick = () => {
        void client.connect();
      };
      parent.append(button);
      return;
    }
    if (!fit) {
      parent.append(el(doc, "p", "muted", "APAS fit is not available for this course."));
      return;
    }
    const statusClass = fit.eligibility.result === "yes" ? "good-text" : fit.eligibility.result === "no" ? "bad-text" : "warn-text";
    parent.append(el(doc, "p", statusClass, fit.eligibility.reason));
    const yes = fit.matches.filter((m) => m.result === "yes"), unknown = fit.matches.filter((m) => m.result === "unknown"), routes = (fit.routes || []).filter((m) => m.result === "yes" && !m.strict);
    if (yes.length) {
      parent.append(el(doc, "h4", void 0, "Matches remaining APAS requirements"));
      for (const m of yes) parent.append(el(doc, "p", "good-text", `\u2713 ${m.label}`));
    } else if (routes.length) {
      parent.append(el(doc, "h4", void 0, "Candidate APAS routes"));
      for (const m of routes.slice(0, 5)) parent.append(el(doc, "p", "warn-text", `\u25C7 ${m.label} \xB7 quantitative cap/condition still needs review`));
    } else parent.append(el(doc, "p", "muted", "No proven match to a remaining APAS requirement."));
    if (unknown.length) {
      parent.append(el(doc, "h4", void 0, "Needs review"));
      for (const m of unknown.slice(0, 5)) parent.append(el(doc, "p", "warn-text", `? ${m.label}`));
    }
    parent.append(el(doc, "p", "muted", "APAS rules can include credit caps and degree-wide conditions. This is an explanation aid, not a guarantee that a course will apply exactly as shown."));
    addPlannerAction(doc, parent, code, term, campus);
  }
  function installEnhancements(doc, client) {
    const win = doc.defaultView;
    const queue = /* @__PURE__ */ new Map();
    const hosts = /* @__PURE__ */ new Map();
    const contextCache = /* @__PURE__ */ new Map();
    const fitCache = /* @__PURE__ */ new Map();
    let timer, stopped = false;
    async function flush() {
      const term = detectTerm(doc);
      if (!term) return;
      const campus = detectCampus(doc) || "UMNTC";
      if (campus !== "UMNTC") return;
      const cacheKey = (code) => campus + ":" + term + ":" + code;
      const cards = [...queue];
      queue.clear();
      for (let i = 0; i < cards.length; i += 12) {
        const group = cards.slice(i, i + 12), codes = [...new Set(group.map((x) => x[1]))];
        const missing = codes.filter((code) => !contextCache.has(cacheKey(code)) || Date.now() - contextCache.get(cacheKey(code)).at > CACHE_MS);
        try {
          if (missing.length) {
            const result = await client.batch(missing, term, campus);
            if (!Array.isArray(result)) throw Error(result.error);
            for (const c of result) if (c.course.data) contextCache.set(cacheKey(c.course.data.code), { at: Date.now(), context: c });
          }
          const fitNeeded = codes.filter((code) => !fitCache.has(cacheKey(code)) || Date.now() - fitCache.get(cacheKey(code)).at > CACHE_MS).map((code) => contextCache.get(cacheKey(code))?.context.course.data).filter((c) => !!c);
          if (fitNeeded.length) {
            const response = await client.fit(fitNeeded);
            if ("error" in response) throw Error(response.error);
            for (const course of fitNeeded) {
              const fit = response.items.find((x) => x.code === course.code) || { code: course.code, eligibility: { result: "unknown", reason: "APAS fit unavailable" }, matches: [] };
              fitCache.set(cacheKey(course.code), { at: Date.now(), fit, connected: response.connected, status: response.status });
            }
          }
          for (const [card, code] of group) {
            const context = contextCache.get(cacheKey(code))?.context;
            const personal = fitCache.get(cacheKey(code));
            paint(card, code, term, campus, context, personal?.fit, personal?.connected ?? false, personal?.status);
          }
        } catch {
          for (const [card, code] of group) paint(card, code, term, campus, contextCache.get(cacheKey(code))?.context, fitCache.get(cacheKey(code))?.fit, fitCache.get(cacheKey(code))?.connected ?? false);
        }
      }
    }
    function enqueue(card, code) {
      queue.set(card, code);
      clearTimeout(timer);
      timer = setTimeout(() => void flush(), 120);
    }
    function paint(card, code, term, campus, c, fit, connected = false, status) {
      if (!card.isConnected || stopped) return;
      let old = hosts.get(card);
      if (old && (!old.host.isConnected || old.code !== code || old.term !== term || old.campus !== campus)) {
        removeInlineHost(old.host);
        hosts.delete(card);
        old = void 0;
      }
      if (old) return;
      const host = doc.createElement("smart-umn-insight");
      host.setAttribute("data-course", code);
      host.setAttribute("data-render-mode", "inline");
      const shadow = host.attachShadow({ mode: "open" }), style = doc.createElement("style");
      style.textContent = css;
      shadow.append(style);
      const mount = el(doc, "div");
      shadow.append(mount);
      let active;
      const render = () => {
        mount.replaceChildren();
        const wrap = el(doc, "section", "wrap"), top = el(doc, "div", "topline");
        top.append(el(doc, "span", "brand", "smart umn"));
        if (!c) {
          top.append(el(doc, "span", "loading", "Planner data unavailable"));
          const link = el(doc, "a", "more-link", "Open planner \u2197");
          link.href = plannerUrl(code, term, campus);
          link.target = "_blank";
          link.rel = "noopener noreferrer";
          top.append(link);
          wrap.append(top);
          mount.append(wrap);
          return;
        }
        const planner = el(doc, "a", "more-link", "Full planner \u2197");
        planner.href = plannerUrl(code, term, campus);
        planner.target = "_blank";
        planner.rel = "noopener noreferrer";
        const context = el(doc, "span", "context", connected ? status || "APAS connected" : "APAS not connected");
        top.append(context, planner);
        wrap.append(top);
        const rail = el(doc, "div", "rail"), toggle = (tab) => () => {
          active = active === tab ? void 0 : tab;
          render();
        };
        const yes = fit?.matches.find((m) => m.result === "yes"), route = fit?.routes?.find((m) => m.result === "yes" && !m.strict);
        const eligibility2 = fit?.eligibility.result;
        const degreeValue = !connected ? "Connect UMN" : eligibility2 === "no" ? "Not eligible now" : yes ? `\u2713 ${short(yes.label, 34)}` : route ? `\u25C7 ${short(route.label, 34)}` : "Needs review";
        const degreeSub = !connected ? "See personalized APAS fit + prerequisite status" : eligibility2 === "no" ? fit?.eligibility.reason || "Not eligible now" : yes ? eligibility2 === "yes" ? fit?.eligibility.reason || "Prerequisites verified" : fit?.eligibility.reason || "Prerequisite conditions need review" : route ? "Candidate route \xB7 caps/conditions need review" : fit?.eligibility.reason || "Personalized APAS check";
        const degreeTone = connected && yes && eligibility2 === "yes" ? "good" : connected && (yes || route || eligibility2 === "unknown" || eligibility2 === "no") ? "warn" : "neutral";
        const degree = insightButton(doc, "APAS fit", degreeValue, degreeSub, degreeTone, "Degree", active, toggle("Degree"));
        degree.setAttribute("data-insight", "degree");
        rail.append(degree);
        if (c.grades.data) {
          const g = c.grades.data, summary = gradeDistributionSummary(g.grades), value = summary.gpa !== void 0 ? `${summary.averageLetter || ""} avg \xB7 ${summary.gpa.toFixed(2)} GPA` : "Historical grades";
          const trend = gradeTermTrend(c), latest = trend.filter((x) => x.gpa !== void 0).at(-1), sub = latest?.gpa !== void 0 ? `${g.totalStudents.toLocaleString()} students \xB7 latest term ${latest.gpa.toFixed(2)} GPA` : summary.mostCommon ? `${summary.mostCommon} most common \xB7 ${summary.mostCommonPercent}% \xB7 ${g.totalStudents.toLocaleString()} students` : `${g.totalStudents.toLocaleString()} historical students`;
          const grades = insightButton(doc, "Grade history", value, sub, "neutral", "Grades", active, toggle("Grades"));
          grades.setAttribute("data-insight", "course-grades");
          grades.append(gradeSpark(doc, g.grades));
          rail.append(grades);
        } else {
          const unavailable = insightButton(doc, "Grade history", "No verified history", `${UMN_CAMPUSES[c.course.data?.campus || campus].name} \xB7 historical source not substituted`, "neutral", "Grades", active, toggle("Grades"));
          unavailable.setAttribute("data-insight", "course-grades-unavailable");
          rail.append(unavailable);
        }
        const histories = currentInstructorGradeHistory(c), signals = currentInstructorSignals(c), leadSignal = signals.find((s) => s.rating) || signals[0];
        if (histories.length || leadSignal) {
          const h = histories[0], summary = h ? gradeDistributionSummary(h.grades) : void 0, value = leadSignal?.rating ? `${leadSignal.rating.quality.toFixed(1)}/5 RMP \xB7 ${leadSignal.instructor.name}` : h?.name || leadSignal?.instructor.name || "Instructor context", sub = leadSignal?.rating ? `${h?.students.toLocaleString() || "No"} grade-history students \xB7 RMP count unavailable` : h ? `${summary?.gpa?.toFixed(2) || "\u2014"} historical GPA \xB7 ${h.students.toLocaleString()} students` : "Current instructor \xB7 no matched rating";
          const instructor = insightButton(doc, "Professor", short(value, 40), sub, "neutral", "Community", active, toggle("Community"));
          instructor.setAttribute("data-insight", "instructor-intelligence");
          if (h) instructor.append(gradeSpark(doc, h.grades));
          rail.append(instructor);
        }
        const refs = newestReferences(c), topics = communityTopicSummary(c), redditRefs = refs.filter((r) => r.source === "reddit");
        {
          const sources = el(doc, "div", "insight neutral");
          sources.setAttribute("data-insight", "references");
          sources.append(el(doc, "span", "kicker", "Student voices"), el(doc, "span", "value", redditRefs.length ? `${redditRefs.length} curated Reddit source${redditRefs.length === 1 ? "" : "s"}` : "Reddit context"), el(doc, "span", "sub", topics.length ? `Themes: ${topics.slice(0, 3).map((t) => t.topic).join(" \xB7 ")}` : "Search original discussions; no sentiment score"));
          const links = el(doc, "div", "source-links");
          for (const r of refs.filter((r2) => r2.source === "reddit").slice(0, 2)) {
            const href = safeExternal(r.url);
            if (!href) continue;
            const a = el(doc, "a", "source-link", `${r.excerpt ? "Excerpt" : "Reddit"} \xB7 ${short(referenceEntityLabel(c, r.entityType, r.entityId), 18)} \u2197`);
            a.href = href;
            a.target = "_blank";
            a.rel = "noopener noreferrer";
            links.append(a);
          }
          if (!redditRefs.length) {
            const a = el(doc, "a", "source-link", "Search Reddit \u2197");
            a.href = redditCourseSearch(code);
            a.target = "_blank";
            a.rel = "noopener noreferrer";
            links.append(a);
          }
          const more = el(doc, "button", "more-link", "Read context");
          more.type = "button";
          more.onclick = toggle("Community");
          links.append(more);
          sources.append(links);
          rail.append(sources);
        }
        {
          const pattern = offeringPattern(c), value = pattern.confidence === "unknown" ? "Limited history" : pattern.seasons.length ? pattern.seasons.join(" / ") : "No observed season", sub = `${pattern.observedTerms.length} observed term${pattern.observedTerms.length === 1 ? "" : "s"} \xB7 ${pattern.confidence} signal`;
          const offering = insightButton(doc, "Offering history", short(value, 38), sub, pattern.confidence === "strong" ? "good" : "neutral", "Offering", active, toggle("Offering"));
          offering.setAttribute("data-insight", "offering-history");
          rail.append(offering);
        }
        wrap.append(rail);
        if (active) {
          const body = el(doc, "div", "body");
          body.setAttribute("data-active-tab", active);
          if (active === "Grades") renderGrades(doc, body, c, code, term);
          if (active === "Community") renderCommunity(doc, body, c, code, term);
          if (active === "Offering") renderOffering(doc, body, c, code, term);
          if (active === "Degree") renderDegree(doc, body, fit, connected, code, term, campus, client);
          wrap.append(body);
        }
        mount.append(wrap);
      };
      render();
      inlineMount(card, code).append(host);
      hosts.set(card, { host, code, term, campus });
    }
    const IO = win.IntersectionObserver;
    const observer = IO ? new IO((entries) => entries.forEach((entry) => {
      if (entry.isIntersecting) {
        const found = findCards(doc).find((c) => c.card === entry.target);
        if (found) enqueue(found.card, found.code);
        observer.unobserve(entry.target);
      }
    }), { rootMargin: "1000px 0px", threshold: 0.01 }) : void 0;
    function scan() {
      for (const [card, entry] of hosts) if (!card.isConnected) {
        removeInlineHost(entry.host);
        hosts.delete(card);
      }
      const term = detectTerm(doc), campus = detectCampus(doc) || "UMNTC";
      if (campus !== "UMNTC") {
        for (const [card, entry] of hosts) {
          removeInlineHost(entry.host);
          hosts.delete(card);
        }
        return;
      }
      for (const { card, code } of findCards(doc)) {
        const old = hosts.get(card);
        if (old && old.host.isConnected && old.code === code && old.term === term && old.campus === campus) continue;
        if (observer) observer.observe(card);
        else enqueue(card, code);
      }
    }
    function refreshPersonalization() {
      fitCache.clear();
      for (const [card, entry] of hosts) {
        removeInlineHost(entry.host);
        hosts.delete(card);
      }
      scan();
    }
    const mo = new win.MutationObserver((records) => {
      if (records.every((r) => r.target.closest?.("smart-umn-insight"))) return;
      scan();
    });
    mo.observe(doc.body, { subtree: true, childList: true });
    win.addEventListener("popstate", scan);
    scan();
    return { scan, refreshPersonalization, disconnect() {
      stopped = true;
      mo.disconnect();
      observer?.disconnect();
      clearTimeout(timer);
      win.removeEventListener("popstate", scan);
    } };
  }

  // apps/extension/schedule.ts
  var app = installEnhancements(document, {
    batch: (codes, term, campus) => chrome.runtime.sendMessage({ type: "CONTEXT_BATCH", codes, term, campus }),
    fit: (courses) => chrome.runtime.sendMessage({ type: "GET_FIT", courses }),
    connect: () => chrome.runtime.sendMessage({ type: "CONNECT" })
  });
  chrome.runtime.onMessage.addListener((message) => {
    if (message?.type === "PERSONALIZATION_CHANGED") app.refreshPersonalization();
  });
})();
//# sourceMappingURL=schedule.js.map

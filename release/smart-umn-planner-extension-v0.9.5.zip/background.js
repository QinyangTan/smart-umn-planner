var __defProp = Object.defineProperty;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __esm = (fn, res) => function __init() {
  return fn && (res = (0, fn[__getOwnPropNames(fn)[0]])(fn = 0)), res;
};
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};

// packages/schemas/index.ts
function campusCode(value) {
  const s = value.trim().toUpperCase();
  if (!(s in UMN_CAMPUSES)) throw new Error("Invalid UMN campus");
  return s;
}
function subjectCode(value) {
  const s = value.trim().toUpperCase();
  if (!/^[A-Z]{2,8}$/.test(s)) throw new Error("Expected a UMN subject such as PSY");
  return s;
}
function parseCampusCourseCode(value) {
  const m = /^\s*([13456])?([A-Z]{2,8})\s*(\d{1,4}[A-Z]?)\s*$/i.exec(value);
  if (!m) throw new Error("Expected a UMN course code such as PSY 1001");
  const subject = m[2].toUpperCase(), catalogNumber = m[3].toUpperCase();
  return { code: `${subject} ${catalogNumber}`, campus: m[1] ? APAS_CAMPUS_DIGITS[m[1]] : void 0, subject, catalogNumber };
}
function courseCode(value) {
  return parseCampusCourseCode(value).code;
}
function termCode(value) {
  if (!/^1\d{2}[359]$/.test(value)) throw new Error("Invalid UMN term");
  return value;
}
function unknownRule(sourceText, reason = "Unsupported or incomplete rule") {
  return { type: "unknown", sourceText, reason };
}
var UMN_CAMPUSES, APAS_CAMPUS_DIGITS;
var init_schemas = __esm({
  "packages/schemas/index.ts"() {
    "use strict";
    UMN_CAMPUSES = { UMNTC: { campus: "UMNTC", institution: "UMNTC", name: "Twin Cities" }, UMNDL: { campus: "UMNDL", institution: "UMNDL", name: "Duluth" }, UMNCR: { campus: "UMNCR", institution: "UMNCR", name: "Crookston" }, UMNMO: { campus: "UMNMO", institution: "UMNMO", name: "Morris" }, UMNRO: { campus: "UMNRO", institution: "UMNTC", name: "Rochester" } };
    APAS_CAMPUS_DIGITS = { "1": "UMNTC", "3": "UMNDL", "4": "UMNMO", "5": "UMNCR", "6": "UMNRO" };
  }
});

// packages/core/rules.ts
var rules_exports = {};
__export(rules_exports, {
  analyzeRequirementRouteCoverage: () => analyzeRequirementRouteCoverage,
  and: () => and,
  courseAttributePairs: () => courseAttributePairs,
  degreeCandidateFit: () => degreeCandidateFit,
  degreeDiscoveryPlan: () => degreeDiscoveryPlan,
  degreeDiscoverySubjects: () => degreeDiscoverySubjects,
  degreeFit: () => degreeFit,
  discoverDegreeCandidates: () => discoverDegreeCandidates,
  eligibility: () => eligibility,
  evaluate: () => evaluate,
  flattenRequirements: () => flattenRequirements,
  matches: () => matches,
  or: () => or,
  parsePrerequisites: () => parsePrerequisites,
  passed: () => passed,
  profileRequirementRoots: () => profileRequirementRoots,
  requirementRouteCoverage: () => requirementRouteCoverage,
  sortCoursesForProfile: () => sortCoursesForProfile
});
function passed(c) {
  if (!["completed", "transfer"].includes(c.status)) return false;
  const grade = (c.grade || "").trim().toUpperCase();
  if (grade) return grade in grades ? grades[grade] > 0 : /^(S|P|T[0-9A-Z+-]*)$/.test(grade);
  return c.status === "transfer" && !!c.transferSource && typeof c.credits === "number" && c.credits > 0;
}
function campusMatch(ruleCampus, campus) {
  return !ruleCampus ? "yes" : !campus ? "unknown" : ruleCampus === campus ? "yes" : "no";
}
function courseAttributePairs(attributes) {
  const out = [];
  for (const raw of attributes || []) {
    try {
      const a = JSON.parse(raw);
      if (a && typeof a === "object" && typeof a.attribute === "string" && typeof a.attribute_value === "string") out.push({ attribute: a.attribute, value: a.attribute_value, name: typeof a.name === "string" ? a.name : void 0 });
    } catch {
    }
  }
  return out;
}
function matches(rule, c) {
  switch (rule.type) {
    case "unknown":
    case "policy":
      return "unknown";
    case "course": {
      const cm = campusMatch(rule.campus, c.campus);
      return cm === "no" ? "no" : rule.code !== c.code ? "no" : cm;
    }
    case "range": {
      const cm = campusMatch(rule.campus, c.campus);
      if (cm === "no") return "no";
      const n = parseInt(c.catalogNumber);
      const hit = c.subject === rule.subject && n >= rule.min && n <= rule.max && (!rule.suffix || c.catalogNumber.endsWith(rule.suffix));
      return hit ? cm : "no";
    }
    case "attribute": {
      const cm = campusMatch(rule.campus, c.campus);
      if (cm === "no") return "no";
      if (!c.attributes) return "unknown";
      const hit = courseAttributePairs(c.attributes).some((a) => a.attribute === rule.attribute && a.value === rule.value);
      return hit ? cm : "no";
    }
    case "anyOf":
      return or(rule.rules.map((r) => matches(r, c)));
    case "allOf":
      return and(rule.rules.map((r) => matches(r, c)));
    case "exclude": {
      const e = or(rule.excluded.map((r) => matches(r, c)));
      return e === "yes" ? "no" : e === "unknown" ? "unknown" : matches(rule.rule, c);
    }
    case "credits":
    case "count":
    case "gpa":
      return matches(rule.rule, c);
  }
}
function evaluate(rule, courses) {
  const done = courses.filter(passed);
  switch (rule.type) {
    case "unknown":
    case "policy":
      return "unknown";
    case "course": {
      const sameCode = done.filter((c) => c.courseCode === rule.code);
      if (!sameCode.length) return "no";
      const found = rule.campus ? sameCode.filter((c) => c.campus === rule.campus) : sameCode;
      if (rule.campus && !found.length) return sameCode.some((c) => !c.campus) ? "unknown" : "no";
      if (!rule.minimumGrade) return "yes";
      return or(found.map((c) => c.grade in grades ? grades[c.grade] >= grades[rule.minimumGrade] ? "yes" : "no" : "unknown"));
    }
    case "anyOf":
      return or(rule.rules.map((r) => evaluate(r, done)));
    case "allOf":
      return and(rule.rules.map((r) => evaluate(r, done)));
    case "credits":
    case "count":
    case "gpa": {
      const selected = done.filter((c) => c.courseCode && matches(rule.rule, { code: c.courseCode, campus: c.campus, subject: c.subject || c.courseCode.split(" ")[0], catalogNumber: c.number || c.courseCode.split(" ")[1] }) === "yes");
      const unique = [...new Map(selected.map((c) => [c.courseCode, c])).values()];
      if (rule.type === "count") return unique.length >= rule.minimum && (rule.maximum === void 0 || unique.length <= rule.maximum) ? "yes" : "no";
      if (unique.some((c) => c.credits === void 0)) return "unknown";
      let credits = unique.reduce((s, c) => s + c.credits, 0);
      if (rule.type === "credits") return credits >= rule.minimum && (rule.maximum === void 0 || credits <= rule.maximum) ? "yes" : "no";
      if (!credits || unique.some((c) => !(c.grade in grades))) return "unknown";
      return unique.reduce((s, c) => s + c.credits * grades[c.grade], 0) / credits >= rule.minimum ? "yes" : "no";
    }
    default:
      return done.some((c) => c.courseCode && matches(rule, { code: c.courseCode, campus: c.campus, subject: c.subject, catalogNumber: c.number }) === "yes") ? "yes" : "no";
  }
}
function parsePrerequisites(source, campus) {
  if (!source.trim()) return unknownRule(source, "No prerequisite information supplied");
  let text = source.replace(/^.*?prereq\s*:\s*/i, "").replace(/^Update:\s*/i, "").replace(/[\[\{]/g, "(").replace(/[\]\}]/g, ")").replace(/,\s*(or|and)\b/gi, " $1 ").trim();
  if (/^(none|no prerequisites)[.]?$/i.test(text)) return { type: "allOf", rules: [] };
  const tokens = text.split(/(\(|\)|\band\b|\bor\b|&)/i).map((s) => s.trim()).filter(Boolean);
  let i = 0;
  function atom() {
    const t = tokens[i++];
    if (t === "(") {
      const r = disjunction();
      if (tokens[i++] !== ")") throw Error();
      return r;
    }
    if (!t || t === ")") throw Error();
    try {
      return { type: "course", code: courseCode(t), ...campus ? { campus } : {} };
    } catch {
      return unknownRule(t, "Standing, consent, grade or other condition requires review");
    }
  }
  function conjunction() {
    const rs = [atom()];
    while (/^(and|&)$/i.test(tokens[i] || "")) {
      i++;
      rs.push(atom());
    }
    return rs.length === 1 ? rs[0] : { type: "allOf", rules: rs };
  }
  function disjunction() {
    const rs = [conjunction()];
    while (/^or$/i.test(tokens[i] || "")) {
      i++;
      rs.push(conjunction());
    }
    return rs.length === 1 ? rs[0] : { type: "anyOf", rules: rs };
  }
  try {
    const r = disjunction();
    return i === tokens.length ? r : unknownRule(source);
  } catch {
    return unknownRule(source);
  }
}
function flattenRequirements(rs) {
  return rs.flatMap((r) => [r, ...flattenRequirements(r.children)]);
}
function profileRequirementRoots(profile) {
  return profile ? [...profile.requirements, ...(profile.additionalPrograms || []).flatMap((p) => p.requirements)] : [];
}
function ruleCanAuthorize(rule) {
  switch (rule.type) {
    case "unknown":
    case "policy":
      return false;
    case "course":
    case "range":
    case "attribute":
      return true;
    case "anyOf":
      return rule.rules.some(ruleCanAuthorize);
    case "allOf":
      return rule.rules.every(ruleCanAuthorize);
    case "exclude":
      return ruleCanAuthorize(rule.rule) && rule.excluded.every((r) => r.type !== "unknown" && ruleCanAuthorize(r));
    case "credits":
    case "count":
    case "gpa":
      return ruleCanAuthorize(rule.rule);
  }
}
function unknownReasons(rule) {
  switch (rule.type) {
    case "unknown":
      return [rule.reason || "Unsupported or incomplete rule"];
    case "policy":
      return [rule.reason || `Recognized ${rule.family} policy is non-authorizing`];
    case "anyOf":
    case "allOf":
      return rule.rules.flatMap(unknownReasons);
    case "exclude":
      return [...unknownReasons(rule.rule), ...rule.excluded.flatMap(unknownReasons)];
    case "credits":
    case "count":
    case "gpa":
      return unknownReasons(rule.rule);
    default:
      return [];
  }
}
function coverageBucket(r, strict, candidate) {
  if (!strict && candidate) return "candidateOnly";
  switch (r.rule.type) {
    case "course":
      return "exactCourse";
    case "range":
      return "subjectRange";
    case "attribute":
      return "officialAttribute";
    case "credits":
      return "credits";
    case "count":
      return "count";
    case "gpa":
      return "gpa";
    case "exclude":
      return "exclusions";
    case "anyOf":
    case "allOf":
      return "nested";
    case "policy":
      return r.rule.family === "institutional-gpa" ? "gpa" : "credits";
    case "unknown":
      if (r.requiredGpa !== void 0) return "gpa";
      if (r.requiredCount !== void 0) return "count";
      if (r.requiredCredits !== void 0) return "credits";
      return "unknown";
  }
}
function summarizeCoverage(requirements) {
  const open = flattenRequirements(requirements).filter((r) => r.status === "incomplete" || r.status === "in_progress");
  const breakdown = { exactCourse: 0, subjectRange: 0, officialAttribute: 0, credits: 0, count: 0, gpa: 0, exclusions: 0, nested: 0, candidateOnly: 0, unknown: 0 };
  const unsupportedReasonHistogram = {};
  let strict = 0, candidate = 0, aggregate = 0, unknown = 0, policy = 0, recognizedPolicy = 0, unclassifiedPolicy = 0;
  for (const r of open) {
    const strictSupported = ruleCanAuthorize(r.rule), candidateSupported = !strictSupported && !!r.candidateRule && ruleCanAuthorize(r.candidateRule);
    if (strictSupported) strict++;
    else if (candidateSupported) candidate++;
    else if (r.children.length) {
      aggregate++;
    } else {
      const policyConstraint = r.rule.type === "policy" || r.requiredCredits !== void 0 || r.requiredCount !== void 0 || r.requiredGpa !== void 0;
      if (policyConstraint) {
        policy++;
        if (r.rule.type === "policy") recognizedPolicy++;
        else unclassifiedPolicy++;
      } else unknown++;
      const reasons = unknownReasons(r.rule);
      for (const reason of reasons.length ? reasons : ["Unsupported or incomplete rule"]) unsupportedReasonHistogram[reason] = (unsupportedReasonHistogram[reason] || 0) + 1;
    }
    breakdown[coverageBucket(r, strictSupported, candidateSupported)]++;
  }
  const total = open.length, pct = (n) => total ? Number((n * 100 / total).toFixed(1)) : 100;
  return { totalActiveRemainingRequirements: total, strictSupportedRequirements: strict, candidateRouteSupportedRequirements: candidate, aggregateContainers: aggregate, unknownUnroutedRequirements: unknown, policyConstraints: policy, recognizedPolicyRules: recognizedPolicy, unclassifiedPolicyConstraints: unclassifiedPolicy, strictCoveragePercent: pct(strict), usefulRouteCoveragePercent: pct(strict + candidate), breakdown, unsupportedReasonHistogram: Object.fromEntries(Object.entries(unsupportedReasonHistogram).sort((a, b) => b[1] - a[1] || a[0].localeCompare(b[0]))) };
}
function analyzeRequirementRouteCoverage(profile) {
  if (!profile) return { overall: summarizeCoverage([]), programs: [] };
  const programs = [{ program: profile.program, requirements: profile.requirements }, ...(profile.additionalPrograms || []).map((p) => ({ program: p.program, requirements: p.requirements }))];
  return { overall: summarizeCoverage(programs.flatMap((p) => p.requirements)), programs: programs.map((p) => ({ programName: p.program.name, programKind: p.program.kind, summary: summarizeCoverage(p.requirements) })) };
}
function requirementRouteCoverage(profile) {
  const summary = analyzeRequirementRouteCoverage(profile).overall;
  return { openRequirements: summary.totalActiveRemainingRequirements, strictRoutes: summary.strictSupportedRequirements, candidateRoutes: summary.candidateRouteSupportedRequirements, policyConstraints: summary.policyConstraints, unresolved: summary.unknownUnroutedRequirements };
}
function degreeFit(course, profile) {
  if (!profile) return [];
  return flattenRequirements(profileRequirementRoots(profile)).filter((r) => r.status === "incomplete" || r.status === "in_progress").map((r) => ({ requirementId: r.id, label: r.label, result: matches(r.rule, course) })).filter((r) => r.result !== "no");
}
function degreeCandidateFit(course, profile) {
  if (!profile) return [];
  return flattenRequirements(profileRequirementRoots(profile)).filter((r) => r.status === "incomplete" || r.status === "in_progress").map((r) => {
    const strict = matches(r.rule, course);
    const candidate = r.candidateRule ? matches(r.candidateRule, course) : strict;
    return { requirementId: r.id, label: r.label, result: strict === "yes" ? "yes" : candidate, strict: strict === "yes" };
  }).filter((r) => r.result !== "no");
}
function degreeDiscoveryPlan(profile, campus) {
  const codes = /* @__PURE__ */ new Set(), subjects = /* @__PURE__ */ new Set(), attrs = /* @__PURE__ */ new Map();
  if (!profile) return { explicitCodes: [], subjects: [], attributes: [] };
  const allowed = (ruleCampus) => !campus || !ruleCampus || ruleCampus === campus;
  const visit = (rule) => {
    switch (rule.type) {
      case "course":
        if (allowed(rule.campus)) codes.add(courseCode(rule.code));
        break;
      case "range":
        if (allowed(rule.campus)) subjects.add(subjectCode(rule.subject));
        break;
      case "attribute":
        if (allowed(rule.campus)) attrs.set(`${rule.attribute}|${rule.value}`, { attribute: rule.attribute, value: rule.value, name: rule.name });
        break;
      case "anyOf":
      case "allOf":
        rule.rules.forEach(visit);
        break;
      case "exclude":
        visit(rule.rule);
        break;
      case "credits":
      case "count":
      case "gpa":
        visit(rule.rule);
        break;
      case "unknown":
      case "policy":
        break;
    }
  };
  for (const r of flattenRequirements(profileRequirementRoots(profile))) if (r.status === "incomplete" || r.status === "in_progress") {
    visit(r.rule);
    if (r.candidateRule) visit(r.candidateRule);
  }
  return { explicitCodes: [...codes].sort(), subjects: [...subjects].sort(), attributes: [...attrs.values()].sort((a, b) => (a.name || a.value).localeCompare(b.name || b.value)) };
}
function degreeDiscoverySubjects(plan, limit = 12) {
  if (!Number.isInteger(limit) || limit < 1 || limit > 64) throw Error("Subject limit must be between 1 and 64");
  const counts = /* @__PURE__ */ new Map();
  for (const code of plan.explicitCodes) {
    const subject = code.split(" ")[0];
    counts.set(subject, (counts.get(subject) || 0) + 1);
  }
  const all = [.../* @__PURE__ */ new Set([...plan.subjects, ...[...counts.keys()].sort((a, b) => counts.get(b) - counts.get(a) || a.localeCompare(b))])];
  return { subjects: all.slice(0, limit), omitted: Math.max(0, all.length - limit) };
}
function sameStudentCourse(c, course) {
  return c.courseCode === course.code && (!c.campus || c.campus === course.campus);
}
function sameStudentCode(c, code, campus) {
  return c.courseCode === code && (!c.campus || c.campus === campus);
}
function sortCoursesForProfile(courses, profile) {
  const rank = (c) => !profile ? 2 : degreeFit(c, profile).some((f) => f.result === "yes") ? 0 : degreeCandidateFit(c, profile).some((f) => f.result === "yes" && !f.strict) ? 1 : 2;
  return [...courses].sort((a, b) => rank(a) - rank(b) || a.code.localeCompare(b.code));
}
function discoverDegreeCandidates(courses, profile) {
  if (!profile) return [];
  const campus = courses[0]?.campus, exact = new Set(degreeDiscoveryPlan(profile, campus).explicitCodes), known = [...profile.completedCourses, ...profile.inProgressCourses, ...profile.transferCourses];
  return [...new Map(courses.map((c) => [`${c.campus}:${c.code}`, c])).values()].filter((c) => !known.some((s) => sameStudentCourse(s, c)) && eligibility(c, profile).result !== "no" && degreeCandidateFit(c, profile).some((f) => f.result === "yes")).sort((a, b) => Number(exact.has(b.code)) - Number(exact.has(a.code)) || Number(eligibility(b, profile).result === "yes") - Number(eligibility(a, profile).result === "yes") || Number(degreeFit(b, profile).some((f) => f.result === "yes")) - Number(degreeFit(a, profile).some((f) => f.result === "yes")) || a.code.localeCompare(b.code));
}
function eligibility(course, profile) {
  if (!profile) return { result: "unknown", reason: "Connect UMN to check prerequisites" };
  const completed = [...profile.completedCourses, ...profile.transferCourses];
  if (completed.some((c) => sameStudentCourse(c, course) && passed(c))) return { result: "no", reason: "Already completed; duplicate credit excluded" };
  const completedEquivalent = completed.find((c) => passed(c) && course.equivalents.some((code) => sameStudentCode(c, code, course.campus)));
  if (completedEquivalent) return { result: "no", reason: `Equivalent course ${completedEquivalent.courseCode} already completed; duplicate credit excluded` };
  if (profile.inProgressCourses.some((c) => sameStudentCourse(c, course))) return { result: "no", reason: "Already in progress" };
  const inProgressEquivalent = profile.inProgressCourses.find((c) => course.equivalents.some((code) => sameStudentCode(c, code, course.campus)));
  if (inProgressEquivalent) return { result: "no", reason: `Equivalent course ${inProgressEquivalent.courseCode} already in progress` };
  if (course.prerequisiteRule.type === "allOf" && !course.prerequisiteRule.rules.length) return { result: "yes", reason: "No prerequisites" };
  const result = evaluate(course.prerequisiteRule, completed);
  return { result, reason: result === "yes" ? "Prerequisites satisfied by completed courses" : result === "no" ? "Prerequisites not satisfied" : "Prerequisite conditions need review" };
}
var and, or, grades;
var init_rules = __esm({
  "packages/core/rules.ts"() {
    "use strict";
    init_schemas();
    and = (v) => v.includes("no") ? "no" : v.includes("unknown") ? "unknown" : "yes";
    or = (v) => v.includes("yes") ? "yes" : v.includes("unknown") ? "unknown" : "no";
    grades = { "A+": 4, A: 4, "A-": 3.67, "B+": 3.33, B: 3, "B-": 2.67, "C+": 2.33, C: 2, "C-": 1.67, "D+": 1.33, D: 1, F: 0 };
  }
});

// apps/extension/background.ts
init_schemas();

// packages/apas-parser/index.ts
init_schemas();
function namespaceRequirement(r, prefix) {
  return { ...r, id: `${prefix}::${r.id}`, label: `${prefix} \xB7 ${r.label}`, rawMetadata: { ...r.rawMetadata, originalLabel: r.label }, children: r.children.map((c) => namespaceRequirement(c, prefix)) };
}
function asAdditionalProgram(profile) {
  return { program: profile.program, requirements: profile.requirements.map((r) => namespaceRequirement(r, profile.program.name)), syncedAt: profile.syncedAt, parserVersion: profile.parserVersion, warnings: profile.warnings, provenance: profile.provenance };
}
function mergeProgramAudit(current, incoming) {
  if (!current) return incoming;
  if (current.program.name === incoming.program.name) return { ...incoming, additionalPrograms: current.additionalPrograms || incoming.additionalPrograms };
  const byName = new Map((current.additionalPrograms || []).map((p) => [p.program.name, p]));
  byName.set(incoming.program.name, asAdditionalProgram(incoming));
  return { ...current, additionalPrograms: [...byName.values()], syncedAt: (/* @__PURE__ */ new Date()).toISOString() };
}

// packages/core/general-education.ts
function norm(value) {
  return value.normalize("NFKC").replace(/\s+/g, " ").trim().toLowerCase();
}
function exactCatalogMatch(label, name) {
  const l = norm(label), n = norm(name);
  if (l === n) return true;
  const rest = l.startsWith(n) ? l.slice(n.length).trim() : "";
  return /^(?:needs\s*:\s*1\s+(?:course|group)|1\s+(?:course|group)\s+(?:needed|required))\b/.test(rest);
}
function qualifiedCatalogCandidate(label, name) {
  const l = norm(label), n = norm(name);
  if (!l.startsWith(n) || l === n) return false;
  const rest = l.slice(n.length).trim();
  return /^(?:with|including|plus|required|requirement\b)/.test(rest);
}
function enrichRequirement(r, catalog) {
  const children = r.children.map((c) => enrichRequirement(c, catalog));
  if (r.status !== "incomplete" && r.status !== "in_progress") return { ...r, children };
  if (r.rule.type === "policy" && r.rule.family === "qualified-attribute") {
    const category = typeof r.rule.parameters.categoryLabel === "string" ? r.rule.parameters.categoryLabel : "";
    const candidate2 = category ? catalog.requirements.find((x) => exactCatalogMatch(category, x.name)) : void 0;
    if (!candidate2) return { ...r, children };
    return { ...r, children, candidateRule: r.candidateRule || { type: "attribute", attribute: candidate2.attribute, value: candidate2.value, name: candidate2.name, campus: catalog.campus }, rawMetadata: { ...r.rawMetadata, catalogEnrichment: { source: "umn-schedule-builder", campus: catalog.campus, term: catalog.term, attribute: candidate2.attribute, value: candidate2.value, name: candidate2.name, confidence: "qualified-policy-candidate" } } };
  }
  if (r.rule.type !== "unknown") return { ...r, children };
  const label = typeof r.rawMetadata.originalLabel === "string" ? r.rawMetadata.originalLabel : r.label;
  const match = catalog.requirements.find((x) => exactCatalogMatch(label, x.name));
  if (match) return { ...r, children, rule: { type: "attribute", attribute: match.attribute, value: match.value, name: match.name, campus: catalog.campus }, candidateRule: r.candidateRule || { type: "attribute", attribute: match.attribute, value: match.value, name: match.name, campus: catalog.campus }, rawMetadata: { ...r.rawMetadata, catalogEnrichment: { source: "umn-schedule-builder", campus: catalog.campus, term: catalog.term, attribute: match.attribute, value: match.value, name: match.name, confidence: "exact" } } };
  const candidate = catalog.requirements.find((x) => qualifiedCatalogCandidate(label, x.name));
  if (!candidate) return { ...r, children };
  return { ...r, children, candidateRule: r.candidateRule || { type: "attribute", attribute: candidate.attribute, value: candidate.value, name: candidate.name, campus: catalog.campus }, rawMetadata: { ...r.rawMetadata, catalogEnrichment: { source: "umn-schedule-builder", campus: catalog.campus, term: catalog.term, attribute: candidate.attribute, value: candidate.value, name: candidate.name, confidence: "qualified-candidate" } } };
}
function enrichGeneralEducation(profile, catalog) {
  if (!catalog || profile.program.campus && profile.program.campus !== catalog.campus) return profile;
  return { ...profile, requirements: profile.requirements.map((r) => enrichRequirement(r, catalog)), additionalPrograms: profile.additionalPrograms?.map((p) => p.program.campus && p.program.campus !== catalog.campus ? p : { ...p, requirements: p.requirements.map((r) => enrichRequirement(r, catalog)) }) };
}

// apps/extension/background.ts
var WEB = "http://127.0.0.1:4317";
var APAS = "https://umn.uachieve.com/selfservice";
chrome.runtime.onInstalled.addListener(() => {
  void chrome.storage.local.setAccessLevel({ accessLevel: "TRUSTED_CONTEXTS" });
  void chrome.alarms.create("apas-sync", { periodInMinutes: 360 });
});
chrome.action.onClicked.addListener(() => {
  void chrome.tabs.create({ url: WEB });
});
async function connect(interactive = true, requestedProgram) {
  const state = await chrome.storage.local.get(["syncTab"]);
  const syncState = { syncStarted: Date.now(), status: "Connecting to UMN", ...requestedProgram ? { requestedProgram } : {} };
  if (state.syncTab) {
    try {
      await chrome.storage.local.set(syncState);
      await chrome.tabs.update(Number(state.syncTab), { active: interactive, url: APAS });
      return;
    } catch {
    }
  }
  const tab = await chrome.tabs.create({ url: APAS, active: interactive });
  await chrome.storage.local.set({ syncTab: tab.id, ...syncState });
}
chrome.alarms.onAlarm.addListener(async (alarm) => {
  if (alarm.name === "apas-sync") {
    const { profile } = await chrome.storage.local.get("profile");
    if (profile) await connect(false);
  }
});
chrome.tabs.onRemoved.addListener(async (id) => {
  const state = await chrome.storage.local.get("syncTab");
  if (state.syncTab === id) await chrome.storage.local.remove("syncTab");
});
chrome.tabs.onUpdated.addListener(async (id, info) => {
  const state = await chrome.storage.local.get("syncTab");
  if (id === state.syncTab && info.url) {
    const u = new URL(info.url);
    if (u.origin !== "https://umn.uachieve.com") {
      await chrome.storage.local.set({ status: "UMN session expired \u2014 reconnect and complete official sign-in" });
      await chrome.tabs.update(id, { active: true });
    }
  }
});
var cache = /* @__PURE__ */ new Map();
async function batch(codes, term, campus) {
  if (!Array.isArray(codes) || codes.length > 12) throw Error("Invalid course batch");
  const t = termCode(String(term)), cp = campusCode(String(campus || "UMNTC"));
  if (cp !== "UMNTC") throw Error("Smart UMN currently supports Twin Cities Schedule Builder only");
  const cs = codes.map((c) => courseCode(String(c))), key = (c) => cp + ":" + t + ":" + c;
  const missing = cs.filter((c) => !cache.has(key(c)) || Date.now() - cache.get(key(c)).at > 3e4);
  if (missing.length) {
    const response = await fetch(WEB + "/api/course-context/batch", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ codes: missing, term: t, campus: cp }), signal: AbortSignal.timeout(2e4) });
    if (!response.ok) throw Error("Local planner API unavailable");
    const values = await response.json();
    for (const v of values) if (v.course.data) cache.set(key(v.course.data.code), { at: Date.now(), value: v });
  }
  return cs.map((c) => cache.get(key(c))?.value).filter(Boolean);
}
chrome.runtime.onMessage.addListener((m, sender, respond) => {
  const senderUrl = sender.url || "";
  const apas = senderUrl.startsWith(APAS + "/");
  const web = senderUrl.startsWith(WEB + "/");
  let sb = false;
  try {
    const u = new URL(senderUrl);
    sb = u.protocol === "https:" && (u.hostname === "schedulebuilder.umn.edu" || u.hostname.endsWith(".schedulebuilder.umn.edu"));
  } catch {
  }
  const internal = senderUrl.startsWith(chrome.runtime.getURL(""));
  (async () => {
    if (!m || typeof m.type !== "string") throw Error("Invalid message");
    switch (m.type) {
      case "CONNECT":
        if (!web && !internal && !sb) throw Error("Unauthorized sender");
        await connect(true, typeof m.payload?.program === "string" ? String(m.payload.program).slice(0, 240) : void 0);
        return { ok: true };
      case "GET_SYNC":
        if (!apas) throw Error("Unauthorized sender");
        {
          const s = await chrome.storage.local.get(["syncTab", "syncStarted", "profile", "requestedProgram"]);
          return { preferredProgram: typeof s.requestedProgram === "string" ? s.requestedProgram : s.profile?.program.name, active: s.syncTab === sender.tab?.id && Date.now() - Number(s.syncStarted) < 18e4 };
        }
      case "APAS_CHOICES":
        if (!apas) throw Error("Unauthorized sender");
        {
          const s = await chrome.storage.local.get("syncTab");
          if (s.syncTab !== sender.tab?.id) throw Error("Unowned sync tab");
          const programs = Array.isArray(m.programs) ? [...new Set(m.programs.filter((x) => typeof x === "string").map((x) => x.slice(0, 240)))].slice(0, 20) : [];
          await chrome.storage.local.set({ availablePrograms: programs });
          return { ok: true };
        }
      case "APAS_RESULT":
        if (!apas) throw Error("Unauthorized sender");
        {
          const s = await chrome.storage.local.get(["syncTab", "profile"]);
          if (s.syncTab !== sender.tab?.id) throw Error("Unowned sync tab");
          const p = m.profile;
          if (!p?.parserVersion || !Array.isArray(p.requirements) || !p.requirements.length || JSON.stringify(p).length > 2e6) throw Error("Invalid normalized audit");
          const current = s.profile, next = mergeProgramAudit(current, p), count = 1 + (next.additionalPrograms?.length || 0);
          await chrome.storage.local.set({ profile: next, status: `UMN Connected \xB7 ${count} APAS program${count === 1 ? "" : "s"} imported` });
          await chrome.storage.local.remove(["syncTab", "requestedProgram"]);
          if (sender.tab?.id) await chrome.tabs.remove(sender.tab.id);
          return { ok: true };
        }
      case "APAS_ERROR":
        if (!apas) throw Error("Unauthorized sender");
        await chrome.storage.local.set({ status: String(m.message).slice(0, 250) });
        return { ok: true };
      case "GET_STATE":
        if (!web && !internal) throw Error("Unauthorized sender");
        return await chrome.storage.local.get(["profile", "plans", "status", "availablePrograms", "selectedCourse", "selectedTerm", "selectedTab"]);
      case "FORGET":
        if (!web && !internal) throw Error("Unauthorized sender");
        await chrome.storage.local.remove(["profile", "plans", "status", "availablePrograms", "requestedProgram"]);
        return { ok: true };
      case "SAVE_PROFILE":
        if (!web && !internal) throw Error("Unauthorized sender");
        {
          const p = m.payload;
          if (!p?.parserVersion || !Array.isArray(p.requirements) || !p.requirements.length || JSON.stringify(p).length > 2e6) throw Error("Invalid normalized audit");
          await chrome.storage.local.set({ profile: p, status: "UMN Connected \xB7 local recovery import" });
          return { ok: true };
        }
      case "SAVE_PLANS":
        if (!web && !internal) throw Error("Unauthorized sender");
        if (!Array.isArray(m.payload) || JSON.stringify(m.payload).length > 1e6) throw Error("Invalid plans");
        await chrome.storage.local.set({ plans: m.payload });
        return { ok: true };
      case "CONTEXT_BATCH":
        if (!sb && !internal) throw Error("Unauthorized sender");
        return batch(m.codes, m.term, m.campus);
      case "GET_FIT":
        if (!sb) throw Error("Unauthorized sender");
        {
          if (!Array.isArray(m.courses) || m.courses.length > 12) throw Error("Invalid course fit batch");
          const courses = m.courses.map((value) => {
            if (!value || typeof value !== "object") throw Error("Invalid course");
            const c = value;
            courseCode(c.code);
            if (c.campus !== "UMNTC") throw Error("Smart UMN currently supports Twin Cities courses only");
            return c;
          });
          const state = await chrome.storage.local.get(["profile", "status"]);
          const profile = state.profile;
          if (!profile) return { connected: false, status: String(state.status || ""), items: courses.map((c) => ({ code: c.code, eligibility: { result: "unknown", reason: "Connect UMN to check prerequisites" }, matches: [] })) };
          const { degreeFit: degreeFit2, degreeCandidateFit: degreeCandidateFit2, eligibility: eligibility2 } = await Promise.resolve().then(() => (init_rules(), rules_exports));
          const enriched = /* @__PURE__ */ new Map();
          for (const c of courses) {
            const cp = campusCode(c.campus || "UMNTC"), t = termCode(c.term), key = cp + ":" + t;
            if (enriched.has(key)) continue;
            let effective = profile;
            try {
              const response = await fetch(WEB + "/api/general-education?campus=" + encodeURIComponent(cp) + "&term=" + encodeURIComponent(t), { signal: AbortSignal.timeout(12e3) });
              if (response.ok) {
                const evidence = await response.json();
                if (evidence.data && !evidence.stale) effective = enrichGeneralEducation(profile, evidence.data);
              }
            } catch {
            }
            enriched.set(key, effective);
          }
          return { connected: true, status: String(state.status || "UMN Connected"), items: courses.map((c) => {
            const p = enriched.get(campusCode(c.campus || "UMNTC") + ":" + termCode(c.term)) || profile;
            return { code: c.code, eligibility: eligibility2(c, p), matches: degreeFit2(c, p), routes: degreeCandidateFit2(c, p) };
          }) };
        }
      default:
        throw Error("Unknown message");
    }
  })().then(respond).catch((err) => respond({ error: err instanceof Error ? err.message : "Extension error" }));
  return true;
});
chrome.storage.onChanged.addListener((changes, area) => {
  if (area !== "local") return;
  void chrome.tabs.query({ url: WEB + "/*" }).then((tabs) => Promise.allSettled(tabs.filter((t) => t.id !== void 0).map((t) => chrome.tabs.sendMessage(t.id, { type: "STATE_CHANGED" }))));
  if (changes.profile || changes.status) void chrome.tabs.query({ url: "https://schedulebuilder.umn.edu/*" }).then((tabs) => Promise.allSettled(tabs.filter((t) => t.id !== void 0).map((t) => chrome.tabs.sendMessage(t.id, { type: "PERSONALIZATION_CHANGED" }))));
});
//# sourceMappingURL=background.js.map

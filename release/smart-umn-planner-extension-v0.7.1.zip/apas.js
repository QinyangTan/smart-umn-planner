"use strict";
(() => {
  // packages/schemas/index.ts
  var APAS_CAMPUS_DIGITS = { "1": "UMNTC", "3": "UMNDL", "4": "UMNMO", "5": "UMNCR", "6": "UMNRO" };
  function parseCampusCourseCode(value) {
    const m = /^\s*([13456])?([A-Z]{2,8})\s*(\d{1,4}[A-Z]?)\s*$/i.exec(value);
    if (!m) throw new Error("Expected a UMN course code such as PSY 1001");
    const subject = m[2].toUpperCase(), catalogNumber = m[3].toUpperCase();
    return { code: `${subject} ${catalogNumber}`, campus: m[1] ? APAS_CAMPUS_DIGITS[m[1]] : void 0, subject, catalogNumber };
  }
  function finite(value) {
    if (value === null || value === void 0 || value === "") return;
    const n = Number(value);
    return Number.isFinite(n) ? n : void 0;
  }
  function unknownRule(sourceText, reason = "Unsupported or incomplete rule") {
    return { type: "unknown", sourceText, reason };
  }

  // packages/apas-parser/index.ts
  var PARSER_VERSION = "0.4.3";
  var text = (n) => {
    if (!n) return "";
    const clone = n.cloneNode(true);
    clone.querySelectorAll("br").forEach((b) => b.replaceWith(" "));
    return (clone.textContent || "").replace(/\s+/g, " ").trim();
  };
  var num = (n) => finite(text(n));
  function status(el) {
    const s = el.matches(".requirement") ? el.className : el.querySelector(".subreqPretext .status")?.className || el.className;
    return /Status_OK/.test(s) ? "complete" : /Status_IP/.test(s) ? "in_progress" : /Status_NO\b/.test(s) ? "incomplete" : /Status_NONE/.test(s) ? "informational" : "unknown";
  }
  function normalizeTerm(t) {
    const m = /^(SP|SU|F)\s*(\d{2})$/i.exec(t);
    return m ? `${{ SP: "Spring", SU: "Summer", F: "Fall" }[m[1].toUpperCase()]} 20${m[2]}` : t;
  }
  function programKind(name) {
    const n = name.trim();
    if (!n) return "unknown";
    if (/\bwhat[- ]?if\b/i.test(n)) return "what_if";
    if (/\bminor\b/i.test(n)) return "minor";
    if (/\bcertificate\b/i.test(n)) return "certificate";
    if (/\bmajor\b/i.test(n)) return "major";
    return "degree";
  }
  function studentCourse(code, title, credits, term, grade, state, transferSource) {
    let parsed;
    try {
      parsed = parseCampusCourseCode(code);
    } catch {
      return null;
    }
    const ip = /in.progress|\bip\b/i.test(state), future = /planned|future/i.test(state);
    const failed = /^(F|N|W|I|NR)$/.test(grade);
    return { courseCode: parsed.code, campus: parsed.campus, subject: parsed.subject, number: parsed.catalogNumber, title, credits: finite(credits), term: normalizeTerm(term), grade, status: ip ? "in_progress" : future ? "future" : failed ? "unknown" : transferSource || /^T/.test(grade) ? "transfer" : /complete/i.test(state) || /^[ABCD][+-]?$|^[SP]$/.test(grade) ? "completed" : "unknown", ...transferSource ? { transferSource } : {} };
  }
  function parseHistory(doc) {
    const tables = [...doc.querySelectorAll("table")];
    const table = tables.find((t) => /Transfer Institution/.test(text(t.querySelector("thead"))));
    if (!table) throw new Error("Course History schema unrecognized");
    const headers = [...table.querySelectorAll("thead th")].map(text);
    const ix = (s) => headers.findIndex((h) => h.toLowerCase() === s.toLowerCase());
    const required = ["Term", "Course", "Credits", "Grade", "Title", "Status"];
    if (required.some((s) => ix(s) < 0)) throw new Error("Course History columns changed");
    return [...table.querySelectorAll("tbody > tr")].map((tr) => {
      const cells = [...tr.children];
      const get = (s) => text(cells[ix(s)] || null);
      const state = cells[ix("Status")];
      return studentCourse(get("Course"), get("Title"), get("Credits"), get("Term"), get("Grade"), get("Status") + " " + [...state?.querySelectorAll("[title],[alt]") || []].map((e) => e.getAttribute("title") || e.getAttribute("alt")).join(" "), get("Transfer Institution/Course") || void 0);
    }).filter((c) => !!c);
  }
  function taken(root2) {
    return [...root2.querySelectorAll("tr.takenCourse")].map((tr) => studentCourse(text(tr.querySelector("td.course")), text(tr.querySelector(".descLine,.description")), text(tr.querySelector(".credit")), text(tr.querySelector(".term")), text(tr.querySelector(".grade")), tr.className + " " + text(tr.querySelector(".ccode")))).filter((c) => !!c);
  }
  function courseRule(el) {
    const raw = (el.getAttribute("department") || "").trim(), m = /^([13456])([A-Z]{2,8})$/i.exec(raw);
    if (!m) return unknownRule(text(el), "Unrecognized UMN campus/designator");
    const campus = APAS_CAMPUS_DIGITS[m[1]], dep = m[2].toUpperCase(), number = (el.getAttribute("number") || "").trim().toUpperCase();
    if (/^\d{1,4}[A-Z]?$/.test(number)) return { type: "course", code: `${dep} ${number}`, campus };
    if (/^\d[X*]{3}$/.test(number)) return { type: "range", subject: dep, min: Number(number[0]) * 1e3, max: Number(number[0]) * 1e3 + 999, campus };
    return unknownRule(text(el), "Unsupported wildcard/range");
  }
  function direct(el, sel) {
    return [...el.querySelectorAll(sel)].find((e) => e.closest(".subrequirement,.requirement") === el) || null;
  }
  function selectableRule(el) {
    const selected = [...el.querySelectorAll(".selectcourses .course[department][number]")].filter((n) => n.closest(".subrequirement,.requirement") === el).map(courseRule).filter((r) => r.type !== "unknown");
    if (!selected.length) return;
    let rule = selected.length === 1 ? selected[0] : { type: "anyOf", rules: selected };
    const excluded = [...el.querySelectorAll(".notcourses .course[department][number]")].filter((n) => n.closest(".subrequirement,.requirement") === el).map(courseRule).filter((r) => r.type !== "unknown");
    if (excluded.length) rule = { type: "exclude", rule, excluded };
    return rule;
  }
  function scopedDesignatorConstraint(label) {
    return /\bof\s+the(?:\s+\d+(?:\.\d+)?)?\s+credits?\b[\s\S]*\b(?:required|needed)\b[\s\S]*\bmust\s+have\s+(?:an?\s+)?[A-Z]{2,8}\s+designator\b/i.test(label);
  }
  function deterministicLabelRule(label) {
    const level = /^(\d)xxx\/(\d)xxx-level\s+([A-Z]{2,8})\s+coursework$/i.exec(label.trim());
    if (level) {
      const subject = level[3].toUpperCase();
      return { type: "anyOf", rules: [{ type: "range", subject, min: Number(level[1]) * 1e3, max: Number(level[1]) * 1e3 + 999, campus: "UMNTC" }, { type: "range", subject, min: Number(level[2]) * 1e3, max: Number(level[2]) * 1e3 + 999, campus: "UMNTC" }] };
    }
    if (scopedDesignatorConstraint(label)) return;
    const designator = /\b(\d+(?:\.\d+)?)\s+(?:credits?\s+)?must\s+have\s+(?:an?\s+)?([A-Z]{2,8})\s+designator\b/i.exec(label);
    if (designator) return { type: "credits", minimum: Number(designator[1]), rule: { type: "range", subject: designator[2].toUpperCase(), min: 0, max: 9999, campus: "UMNTC" } };
    return;
  }
  function parseRule(el, label) {
    if (scopedDesignatorConstraint(label) && !selectableRule(el)) return unknownRule(label, "Designator-credit constraint is scoped to another requirement and cannot independently authorize courses");
    const base = selectableRule(el) || deterministicLabelRule(label);
    if (!base) return unknownRule(label, "No explicit selectable course rule");
    const unresolvedCompound = /\b(note:|combined|permission|approval|0-2|up to|not count more|no more than)\b/i.test(label) || /\bexcept\b/i.test(label) && base.type !== "exclude";
    if (unresolvedCompound) return unknownRule(label, "Compound cap or exception needs a richer rule");
    let rule = base;
    const hours = finite(el.getAttribute("rqdhours")), requiredCount = finite(el.getAttribute("rqdcount")) || finite(el.getAttribute("rqdsubreq")), needsCount = num(direct(el, ".reqNeeds .count,.subreqNeeds .count")), max = finite(el.getAttribute("maxhours"));
    if (rule.type === "credits" || rule.type === "count" || rule.type === "gpa") return rule;
    if (hours && hours > 0) rule = { type: "credits", minimum: hours, ...max !== void 0 && max < 999 ? { maximum: max } : {}, rule };
    else if (requiredCount && requiredCount > 0) rule = { type: "count", minimum: requiredCount, rule };
    else if (needsCount && needsCount > 0) rule = { type: "count", minimum: needsCount, rule };
    else if (!deterministicLabelRule(label)) return unknownRule(label, "Selectable list exists, but count/credit semantics are not proven");
    const gpa = finite(el.getAttribute("rqdgpa"));
    if (gpa && gpa > 0) rule = { type: "gpa", minimum: gpa, rule };
    return rule;
  }
  function requirement(el, index) {
    const sub = el.matches(".subrequirement");
    const label = text(el.querySelector(sub ? ".subreqTitle" : ".reqTitle")) || text(el.querySelector(sub ? ".subreqBody" : ".reqText")) || el.getAttribute("rname") || "Untitled requirement";
    const children = [...el.querySelectorAll(".subrequirement")].filter((e) => e.parentElement?.closest(".subrequirement,.requirement") === el).map((e, i) => requirement(e, `${index}.${i}`));
    const ownCandidate = selectableRule(el) || deterministicLabelRule(label), childCandidates = children.map((c) => c.candidateRule || (c.rule.type !== "unknown" ? c.rule : void 0)).filter((r) => !!r), candidateRule = ownCandidate || (childCandidates.length === 1 ? childCandidates[0] : childCandidates.length ? { type: "anyOf", rules: childCandidates } : void 0);
    const rawMetadata = { attributes: Object.fromEntries([...el.attributes].filter((a) => !/^on|href|src/i.test(a.name)).map((a) => [a.name, a.value])), sourceText: label, selectableCourses: [...el.querySelectorAll(".selectcourses .course[department][number]")].map((e) => ({ department: e.getAttribute("department"), number: e.getAttribute("number") })), candidateRoute: !!candidateRule };
    const requiredCount = finite(el.getAttribute("rqdcount")) || finite(el.getAttribute("rqdsubreq"));
    return { id: index, code: el.getAttribute(sub ? "pseudo" : "rname") || void 0, label, status: status(el), requiredCredits: finite(el.getAttribute("rqdhours")), appliedCredits: num(direct(el, ".reqEarned .hours,.subreqEarned .hours")), inProgressCredits: num(direct(el, ".reqIpDetail .hours,.subreqIpHours .hours")), remainingCredits: num(direct(el, ".reqNeeds .hours,.subreqNeeds .hours")), requiredCount, appliedCount: num(direct(el, ".reqEarned .count,.subreqEarned .count")), inProgressCount: num(direct(el, ".reqIpDetail .count,.subreqIpHours .count")), remainingCount: num(direct(el, ".reqNeeds .count,.subreqNeeds .count")), requiredGpa: finite(el.getAttribute("rqdgpa")), coursesUsed: [...new Set(taken(el).map((c) => c.courseCode))], children, rule: parseRule(el, label), ...candidateRule ? { candidateRule } : {}, rawMetadata };
  }
  function parseAPAS(doc, history) {
    const root2 = doc.querySelector("#audit") || doc.body;
    if (!root2.querySelector(".requirement")) throw new Error("APAS schema unrecognized; no semantic requirements");
    const requirements = [...root2.querySelectorAll(".requirement")].filter((e) => !e.parentElement?.closest(".requirement")).map((e, i) => requirement(e, `r${i}`));
    const h = doc.querySelector(".card-header");
    const heading = text(h?.querySelector("h2") || doc.querySelector("[data-program]"));
    const info = text(h || doc.querySelector("[data-program]"));
    let warnings = [];
    let courses = taken(root2);
    if (history) {
      try {
        courses = parseHistory(history);
      } catch {
        warnings.push("Course History unavailable or changed; using audit rows");
      }
    }
    courses = [...new Map(courses.map((c) => [`${c.campus}|${c.courseCode}|${c.term}|${c.grade}`, c])).values()];
    const totals = requirements.filter((r) => {
      const attrs = r.rawMetadata.attributes || {}, cls = String(attrs.class || "");
      return /(?:^|\s)category_Total_Hours(?:\s|$)/.test(cls) || /^(?:minimum\s+(?:total\s+)?degree\s+(?:credits|hours)|(?:minimum\s+)?(?:total\s+)?credits?\s+(?:required\s+)?for\s+(?:the\s+)?degree|total\s+degree\s+credits?)(?:\s*[:.\-]\s*\d+)?$/i.test(r.label.trim());
    });
    const total = totals.length === 1 ? totals[0] : void 0;
    if (!total) warnings.push("Degree credit total not uniquely recognized; consult the official audit");
    if (!heading) warnings.push("Program heading not recognized");
    const campuses = [...new Set(courses.map((c) => c.campus).filter(Boolean))];
    const programCampus = campuses.length === 1 ? campuses[0] : void 0;
    return { program: { name: heading || "Program not recognized", kind: programKind(heading || ""), campus: programCampus, catalogYear: /Catalog Year\s+((?:Fall|Spring|Summer)\s+\d{4}|\d{4})/i.exec(info)?.[1], expectedGraduation: /Expected Grad Term\s+((?:Spr|Spring|Fall|Summer)\s+\d{4})/i.exec(info)?.[1] }, degreeCredits: { required: total?.requiredCredits, completed: total?.appliedCredits, inProgress: total?.inProgressCredits, remaining: total?.remainingCredits }, completedCourses: courses.filter((c) => c.status === "completed"), inProgressCourses: courses.filter((c) => c.status === "in_progress"), transferCourses: courses.filter((c) => c.status === "transfer"), requirements, syncedAt: (/* @__PURE__ */ new Date()).toISOString(), parserVersion: PARSER_VERSION, warnings, provenance: { source: "umn-apas", retrievedAt: (/* @__PURE__ */ new Date()).toISOString(), period: /Prepared On\s+(\d{2}\/\d{2}\/\d{4})/.exec(info)?.[1] || "Audit period not recognized" } };
  }
  function discoverAuditLinks(doc, base) {
    return [...new Set([...doc.querySelectorAll("a[href]")].map((a) => {
      try {
        const u = new URL(a.getAttribute("href"), base);
        return u.origin === "https://umn.uachieve.com" && u.pathname === "/selfservice/audit/read.html" && u.searchParams.has("id") ? u.href : "";
      } catch {
        return "";
      }
    }).filter(Boolean))];
  }
  function discoverAuditChoices(doc, base) {
    const links = discoverAuditLinks(doc, base);
    const entries = links.map((href) => {
      const a = [...doc.querySelectorAll("a[href]")].find((a2) => new URL(a2.getAttribute("href"), base).href === href);
      const row = a?.closest("tr"), table = row?.closest("table"), headers = [...table?.querySelectorAll("thead th") || []].map(text), cells = [...row?.children || []], title = text(cells[headers.findIndex((h) => h === "Title")] || null), created = text(cells[headers.findIndex((h) => h === "Created")] || null);
      return { href, title, created: created || void 0, time: Date.parse(created) };
    }).filter((e) => e.title);
    const latest = /* @__PURE__ */ new Map();
    for (const e of entries) {
      const old = latest.get(e.title);
      if (!old || Number.isFinite(e.time) && (!Number.isFinite(old.time) || e.time > old.time)) latest.set(e.title, e);
    }
    const rank = (title) => ({ degree: 0, major: 1, minor: 2, certificate: 3, what_if: 4, unknown: 5 })[programKind(title)];
    return [...latest.values()].sort((a, b) => rank(a.title) - rank(b.title) || (Number.isFinite(b.time) ? b.time : 0) - (Number.isFinite(a.time) ? a.time : 0) || a.title.localeCompare(b.title));
  }
  function selectLatestAudit(doc, base, preferredProgram) {
    const entries = discoverAuditChoices(doc, base);
    if (!entries.length) throw Error("No audit links found");
    let eligible = preferredProgram ? entries.filter((e) => e.title === preferredProgram) : entries;
    if (!preferredProgram && entries.length > 1) {
      const primary = entries.filter((e) => ["degree", "major"].includes(programKind(e.title)));
      if (new Set(primary.map((e) => e.title)).size === 1) eligible = primary;
      else throw Error("Multiple APAS program audits found. Choose the program you want to sync.");
    }
    if (!eligible.length) throw Error("Requested APAS program is absent from the completed audit list.");
    if (eligible.length === 1) return eligible[0].href;
    if (eligible.some((e) => !Number.isFinite(e.time))) throw Error("Audit dates not recognized; choose the intended program audit once.");
    eligible.sort((a, b) => b.time - a.time);
    if (eligible[0].time === eligible[1].time) throw Error("Audit dates are tied; choose the intended program audit once.");
    return eligible[0].href;
  }

  // apps/extension/apas.ts
  var send = (m) => chrome.runtime.sendMessage(m);
  var root = "https://umn.uachieve.com";
  async function getDocument(href) {
    const u = new URL(href, location.href);
    if (u.origin !== root || !u.pathname.startsWith("/selfservice/audit/")) throw Error("Invalid first-party APAS path");
    const r = await fetch(u.href, { credentials: "same-origin", redirect: "error", signal: AbortSignal.timeout(2e4) });
    if (!r.ok) throw Error("UMN session expired \u2014 reconnect");
    const html = await r.text();
    if (html.length > 5e6) throw Error("Audit size changed");
    return new DOMParser().parseFromString(html, "text/html");
  }
  async function sync() {
    const state = await send({ type: "GET_SYNC" });
    if (!state?.active) return;
    try {
      let audit = document;
      if (!document.querySelector(".requirement")) {
        const links = discoverAuditLinks(document, location.href);
        if (links.length) {
          const choices = discoverAuditChoices(document, location.href);
          if (choices.length) await send({ type: "APAS_CHOICES", programs: choices.map((c) => c.title) });
          location.assign(selectLatestAudit(document, location.href, state.preferredProgram));
          return;
        }
        const link = [...document.querySelectorAll("a[href]")].find((a) => a.origin === root && /\/selfservice\/audit\/(list|manage)\.html$/.test(a.pathname));
        const key = "smart-umn-discovery-hops";
        const hops = Number(sessionStorage.getItem(key) || 0);
        if (link && hops < 3) {
          sessionStorage.setItem(key, String(hops + 1));
          location.assign(link.href);
          return;
        }
        throw Error("No existing audit found automatically. Complete UMN sign-in or request an audit in this official tab; sync will resume.");
      }
      let history;
      const h = document.querySelector('a[href*="/audit/listcourses.html"]');
      if (h) {
        try {
          history = await getDocument(h.href);
        } catch {
        }
      }
      let profile;
      try {
        profile = parseAPAS(audit, history);
      } catch (error) {
        const printer = document.querySelector('a[href*="printerFriendly=true"]');
        if (!printer) throw error;
        audit = await getDocument(printer.href);
        profile = parseAPAS(audit, history);
      }
      if (!history) profile.warnings.push("Course History not loaded; audit course rows used");
      const response = await send({ type: "APAS_RESULT", profile });
      if (response?.error) throw Error(response.error);
    } catch (error) {
      await send({ type: "APAS_ERROR", message: error instanceof Error ? error.message : "APAS parsing failed" });
    }
  }
  void sync();
  setTimeout(() => void sync(), 1200);
})();
//# sourceMappingURL=apas.js.map
